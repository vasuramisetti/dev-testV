#!/bin/bash

SWN_APPS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com"
SWN_WEBS=""
SWN_INETS=""
SWN_ADMS=""

DEN06_APPS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"
DEN06_WEBS=""
DEN06_INETS=""
DEN06_ADMS=""

PREPROD_APPS="app-pre-1-ucs.utilities.west.com app-pre-2-ucs.utilities.west.com"
PREPROD_WEBS=""
PREPROD_INETS=""
PREPROD_ADMS=""

BETA_APPS="app-dev-1-ucs.utilities.west.com"
BETA_WEBS=""
BETA_INETS=""
BETA_ADMS=""

APPS="myapp"
WEBS="myapp"
INETS=""
ADMS=""



SHUTDOWN_COMMAND="/opt/sfw/bin/sudo /usr/sbin/svcadm disable -s /ucs/app/alarmd"
CLEAR_SMF_COMMAND="/opt/sfw/bin/sudo /usr/sbin/svcadm clear /ucs/app/alarmd"
STARTUP_COMMAND="/opt/sfw/bin/sudo /usr/sbin/svcadm enable -s /ucs/app/alarmd"
TEST_CLEAR_COMMAND="/opt/sfw/bin/sudo /usr/local/bin/touch /var/spool/alarmd/ALARMD_PURGE_ALL_ALARM_FILES"
PROD_CLEAR_COMMAND="/opt/sfw/bin/sudo /usr/bin/rm -f /var/spool/alarmd/*"
VERIFY="/usr/bin/svcs /ucs/app/alarmd"

# print usage info
function usage
{
echo "$0 <USERNAME> <SWN01|DEN06|PREPROD|BETA|DEV|ALLPROD> <SHUTDOWN|STARTUP>";
}


if [ -z $3 ]; then 
usage
exit 1
fi

USERNAME=$1
USERCOMMAND=$3
SHUTDOWN=0;
STARTUP=0;
CLEAR_COMMAND=$PROD_CLEAR_COMMAND

case $USERCOMMAND in
        "SHUTDOWN" )  SHUTDOWN=1;;
        "STARTUP" )   STARTUP=1;;
        * )   usage
              exit 1
esac

if [ $2 = "SWN01" ]; then
APPS=$SWN_APPS
WEBS=$SWN_WEBS
INETS=$SWN_INETS
ADMS=$SWN_ADMS
fi
if [ $2 = "DEN06" ]; then
APPS=$DEN06_APPS
WEBS=$DEN06_WEBS
INETS=$DEN06_INETS

fi
if [ $2 = "ALLPROD" ]; then
  if [ -z "$SWN_APPS" ]; then
    APPS=$DEN06_APPS   
  else
    APPS="$DEN06_APPS $SWN_APPS"
  fi
  if [ -z "$SWN_WEBS" ]; then
    WEBS=$DEN06_WEBS
  else
    WEBS="$DEN06_WEBS $SWN_WEBS"
  fi
  if [ -z "$SWN_INETS" ]; then
   INETS=$DEN06_INETS
  else 
    INETS="$DEN06_INETS $SWN_INETS"
  fi
  if [ -z "$SWN_ADMS" ]; then
    ADMS=$DEN06_ADMS
  else 
    ADMS="$DEN06_ADMS $SWN_ADMS"
  fi
fi
if [ $2 = "PREPROD" ]; then
APPS=$PREPROD_APPS
WEBS=$PREPROD_WEBS
INETS=$PREPROD_INETS
ADMS=$PREPROD_ADMS
CLEAR_COMMAND=$TEST_CLEAR_COMMAND
fi
if [ $2 = "BETA" ]; then
APPS=$BETA_APPS
WEBS=$BETA_WEBS
INETS=$BETA_INETS
ADMS=$BETA_ADMS
CLEAR_COMMAND=$TEST_CLEAR_COMMAND
fi
if [ $2 = "DEV" ]; then
APPS="myapp"
WEBS="myweb"
INETS=
ADMS=
fi

if [ $2 = "DEV" ]; then
APPS="myapp"
WEBS="myweb"
INETS=
ADMS=
fi








COMMANDS=""
echo "Creating PlatformConfig Files"



#echo "$COMMANDS"

if [ -z "$APPS" ]; then
  echo "Skipping App servers, Nothing to do."
else
  echo "Initialing Managers on Appservers"
  for server in $APPS; do
    echo "Setting up Managers!"
    echo "Setting Up Appserver : $server"
    if [ $SHUTDOWN = 1 ]; then
      echo "ssh -t $1@$server $SHUTDOWN_COMMAND"; 
      ssh -t $1@$server $SHUTDOWN_COMMAND
    else 
      echo "ssh -t $1@$server $CLEAR_COMMAND"; 
      ssh -t $1@$server $CLEAR_COMMAND
      echo "Clearing Any Maintenance"
      ssh -t $1@$server $CLEAR_SMF_COMMAND
      echo "ssh -t $1@$server $STARTUP_COMMAND"; 
      ssh -t $1@$server $STARTUP_COMMAND
      ssh -t $1@$server $VERIFY
    fi
    #ssh -t $1@$server "$COMMANDS"
  done;
fi

if [ -z "$WEBS" ]; then
  echo "Skipping Web servers, Nothing to do."
else
  echo "Deploying WebServers"
  for server in $WEBS; do
    if [ $SHUTDOWN = 1 ]; then
      echo "ssh -t $1@$server $SHUTDOWN_COMMAND"; 
      ssh -t $1@$server $SHUTDOWN_COMMAND
    else 
      echo "ssh -t $1@$server $CLEAR_COMMAND"; 
      ssh -t $1@$server $CLEAR_COMMAND
      echo "Clearing Any Maintenance"
      ssh -t $1@$server $CLEAR_SMF_COMMAND
      echo "ssh -t $1@$server $STARTUP_COMMAND"; 
      ssh -t $1@$server $STARTUP_COMMAND
      ssh -t $1@$server $VERIFY
    fi
  done;
fi

if [ -z "$INETS" ]; then
  echo "Skipping Inet servers, Nothing to do."
else
  echo "Deploying INET Servers"
  for server in $INETS; do
    if [ $SHUTDOWN = 1 ]; then
      echo "ssh -t $1@$server $SHUTDOWN_COMMAND"; 
      ssh -t $1@$server $SHUTDOWN_COMMAND
    else 
      echo "ssh -t $1@$server $CLEAR_COMMAND"; 
      ssh -t $1@$server $CLEAR_COMMAND
      echo "Clearing Any Maintenance"
      ssh -t $1@$server $CLEAR_SMF_COMMAND
       echo "ssh -t $1@$server $STARTUP_COMMAND"; 
      ssh -t $1@$server $STARTUP_COMMAND
      ssh -t $1@$server $VERIFY
    fi
  done;
fi

if [ -z "$ADM" ]; then
  echo "Skipping Admin servers, Nothing to do."
else
  echo "Deploying Admin Web Servers"
  for server in $ADM; do
    if [ $SHUTDOWN = 1 ]; then
      echo "ssh -t $1@$server $SHUTDOWN_COMMAND"; 
      ssh -t $1@$server $SHUTDOWN_COMMAND
    else 
      echo "ssh -t $1@$server $CLEAR_COMMAND"; 
      ssh -t $1@$server $CLEAR_COMMAND
      echo "ssh -t $1@$server $STARTUP_COMMAND"; 
      ssh -t $1@$server $CLEAR_SMF_COMMAND
      ssh -t $1@$server $STARTUP_COMMAN
      ssh -t $1@$server $VERIFY
    fi
  done;
fi

echo "END PlatformConfig DEPLOYMENT"

echo "Cleaning Up Configurations"


echo "Clean up Completed"
