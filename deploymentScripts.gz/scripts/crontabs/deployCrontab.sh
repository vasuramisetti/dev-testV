#!/bin/bash

user=$(whoami)
directory="crons"
fileEnd="_new"


# print usage info
function usage
{
echo "$0 --directory <DIRECTORY> --rollback"
echo ""
echo "Arguments:" 
echo " --rollback (to previous files)"
echo " --directory <directory with files to deploy>"
}

# parse and set opts
function getCommandLine {

while [ "$1" != "" ]; do
    echo "$1";
    case $1 in
        --rollback)                   fileEnd="_bk"
                                      ;;
        --directory )                 shift
                                     directory=$1
                                     ;;
        -h | --help )                usage
                                     exit
                                     ;;
        * )                          usage
                                     exit 1
    esac
    shift
done

}

if [ "$1" = "" ]; then
usage
exit 1
fi

getCommandLine $@

mkdir -p $directory;
for file in `ls $directory/*$fileEnd`; do
IFS='_' read -ra FILEPARTS <<< "$file"
echo "found File $file";
baseFilename=`basename $file`;

owner=${FILEPARTS[1]};
server=${FILEPARTS[2]};
echo "OWNER: $owner";
echo "Sending $file to Server: $server /var/tmp directory";
scp $file $user@$server:/var/tmp/$baseFilename;
echo "Setting $baseFilename as crontab for user $owner on $server"
ssh -t $user@$server /opt/sfw/bin/sudo -u $owner crontab /var/tmp/$baseFilename
echo "Cleaning up /var/tmp/$baseFilename on $server"
ssh -t $user@$server rm /var/tmp/$baseFilename
done;

