#!/bin/bash

scriptPath=$(dirname $0)
source $scriptPath/../server-variables.sh

servers=
platform=
class="APP"
task=
file=
deployToDirectory=
service=
graceful=0
user=$(whoami)
owner="tfccapp"
permissions="775"

# print usage info
function usage
{
echo "$0 --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> --class <WEB|APP> --owner <fileowner tfccapp by default>";
echo ""
echo "Arguments:" 
echo " --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> (required)"
echo " --class <WEB|APP|INET|ADM> (optional) defaults to APP"
echo " --owner <file owned by user> defaults: tfccapp"
echo ""

}

# parse and set opts
function getCommandLine {

while [ "$1" != "" ]; do
    echo $1;
    case $1 in
        --class)                     shift;
                                     class=$1
                                     ;;
        --platform)                  shift
                                     platform=$1
                                     ;;
        --user)                      shift
                                     user=$1;;
        --owner)                     shift
                                     owner=$1;;
        -h | --help )                usage
                                     exit
                                     ;;
        * )                          usage
                                     exit 1
    esac
    shift
done

}

if [ "$1" = "" ]; then
usage
exit 1
fi

getCommandLine $@

getServers $platform $class
echo "Manual SERVERS: $servers"

mkdir -p crons;
for server in $servers; do
ssh -t $user@$server "/opt/sfw/bin/sudo crontab -l $owner > /tmp/crontab_${owner}_${server} ";
scp $user@$server:/tmp/crontab_${owner}_${server} crons/.;
ssh -t $user@$server rm /tmp/crontab_${owner}_${server} ;
done;

