#!/bin/bash

scriptPath=$(dirname $0)
source $scriptPath/../server-variables.sh

servers=
platform=
class="APP"
task=
file=
deployToDirectory=
service=
graceful=0
user=$(whoami)
owner="tfccapp"
permissions="775"
active_server=
new_crontab_file=
directory="crons"

# print usage info
function usage
{
echo "$0 --user <USERNAME yours by default> --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> --class <WEB|APP> --file <FILE TO DEPLOY> --deployToDirectory <SERVERDIR> --serviceToRestart <service to restart (none by default)> --permissions <permissions on file 775 default> --owner <fileowner tfccapp by default>";
echo ""
echo "Arguments:" 
echo " --active-server <sunXXX|esx-XXX> server which the non commented out cron should be"
echo " --new-crontab-file <filename> contains the new crontabs"

}

# parse and set opts
function getCommandLine {

while [ "$1" != "" ]; do
    echo $1;
    case $1 in
        --directory)                 shift
                                     directory=$1;;
        --active-server)             shift
                                     active_server=$1;;
        --new-crontab-file)          shift
                                     new_crontab_file=$1;;
        -h | --help )                usage
                                     exit
                                     ;;
        * )                          usage
                                     exit 1
    esac
    shift
done

}

if [ "$1" = "" ]; then
usage
exit 1
fi

getCommandLine $@

 

mkdir -p $directory;
rm $directory/*_new
for file in `ls $directory`; do
  #crontab.$owner.$class.$platform.$server
  cp $directory/$file $directory/${file}_new;
  echo "" >> $directory/${file}_new;
  IFS='_' read -ra FILEPARTS <<< "$file"
  server=${FILEPARTS[2]}
  if [ "$server" = "$active_server" ]; then
    cat $new_crontab_file >> $directory/${file}_new;
  else
    echo "$server is not the active server $new_crontab_file"
    sed -e "s/^/#/" $new_crontab_file >> $directory/${file}_new;
  fi
  mv $directory/$file $directory/${file}_bk
done;

