#!/bin/bash


function die {
  echo "$1"
  exit;
}

if [ -z $6 ]; then
echo "$0 - <file To Deploy> <deployment path> <owner> <permissions> <restart service> <server1> <server2> .. <serverN>"
fi

file=$1;
deployTo=$2
owner=$3
permissions=$4;
restartService=$5;
shift;
shift;
shift;
shift;
shift;
servers="$@"

echo "SERVERS: $servers";

fileName=`basename $file`

echo "$owner" | grep ':'
if [ $? -eq 0 ]; then
echo "owner ($owner) has a group already"
else
owner=$owner:tfcclog
echo "owner has no group using tfcclog ($owner)"
fi

for server in $servers; do

echo "Copying File to $server";
scp $file $server:/tmp/. || die "Failed SCP File to $server!";
echo "Changing Ownership/Permissions of $owner:tfcclog $permissions $fileName";
ssh -t $server chmod $permissions /tmp/$fileName || die "Failed to chmod File!";
ssh -t $server /opt/sfw/bin/sudo chown $owner /tmp/$fileName || die "Failed to Chown File!";
echo "Moving file $fileName to $deployTo/.";
ssh -t $server /opt/sfw/bin/sudo mv /tmp/$fileName $deployTo/. || die "Failied to deploy file to $deployTo !" ;

ssh -t $server ls -l $deployTo/$fileName || die "Failed ls deployed File on $server!";

if [ -z $restartService ]; then
: # do nothing
else 
echo "Restarting Service $restartService"
ssh -t $server /opt/sfw/bin/sudo /usr/sbin/svcadm disable -s $restartService || die "Failed ls stop service on $server!";
ssh -t $server /opt/sfw/bin/sudo /usr/sbin/svcadm enable -s $restartService || die "Failed ls start service on $server!";
ssh -t $server /usr/bin/svcs -a $restartService || die "Failed ls check service on $server!";
fi
done
