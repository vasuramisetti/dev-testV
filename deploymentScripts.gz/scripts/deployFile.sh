#!/bin/bash

scriptPath=$(dirname $0)
source $scriptPath/server-variables.sh

servers=
platform=
class=
task=
file=
deployToDirectory=
service=
graceful=0
user=$(whoami)
owner="tfccapp"
permissions="775"

# print usage info
function usage
{
echo "$0 --user <USERNAME yours by default> --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> --class <WEB|APP> --file <FILE TO DEPLOY> --deployToDirectory <SERVERDIR> --serviceToRestart <service to restart (none by default)> --permissions <permissions on file 775 default> --owner <fileowner tfccapp by default>";
echo ""
echo "Arguments:" 
echo " --user <USER TO DEPLOY AS> (optional) defaults:user running script"
echo " --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> (required)"
echo " --class <WEB|APP|INET|ADM> (optional if task set)"
echo " --file <FILE TO DEPLOY> (required)"
echo " --deployToDirectory <Directory on the server the file should be deployed into>"
echo " --serviceToRestart <service to restart> default: none"
echo " --permissions <permissions> defaults: 775"
echo " --owner <file owned by user> defaults: tfccapp"
echo " --task <Task to run> requires specific parameters"
echo ""
echo "  Current Implemented Tasks:"
echo "    SIGNUP_LOGO - Public signup Logos"
echo "    Usage: $0 --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> --task SIGNUP_LOGO --file <FILE TO DEPLOY>"
echo ""
echo "    TOMCAT1 - Tomcat1 wars"
echo "    Usage: $0 --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> --task TOMCAT1 --file <FILE TO DEPLOY>"
echo ""
echo "    TOMCAT2 - Tomcat2 wars"
echo "    Usage: $0 --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> --task TOMCAT1 --file <FILE TO DEPLOY>"
echo ""
echo "    JAVA_PROPERTY - Java Property File"
echo "    Usage: $0 --platform <ATL01|DEN06|PREPROD|BETA|ALLPROD> --task JAVA_PROPERTY --file <FILE TO DEPLOY>"

}

# parse and set opts
function getCommandLine {

while [ "$1" != "" ]; do
    echo $1;
    case $1 in
        --platform )                 shift
                                     platform=$1
                                     ;;
        --class )                    shift
                                     class=$1
                                     ;;
        --task )                     shift
                                     task=$1
                                     ;;
        --file )                     shift
                                     file=$1
                                     ;;
        --deployToDirectory )        shift
                                     deployDirectory=$1
                                     ;;
        --serviceToRestart )         shift
                                     service=$1
                                     ;;
        --graceful )                 graceful=1
                                     ;;
        --user)                      shift
                                     user=$1;;
        --owner)                     shift
                                     owner=$1;;
        --permissions)               shift
                                     permisssions=$1;;
        -h | --help )                usage
                                     exit
                                     ;;
        * )                          usage
                                     exit 1
    esac
    shift
done

}

getCommandLine $@

if [ -z "$task" ]; then
  getServers $platform $class
  echo "Manual SERVERS: $servers"
  . $scriptPath/deploy-Single-File.sh $file $deployDirectory $owner $permissions "$service" $servers
  exit
else
   case $task in
  SIGNUP_LOGO )
    echo "Deploying SIGNUP LOGOs"
     getServers $platform "WEB"
      echo "PS SERVERS: $servers"
    . $scriptPath/deploy-Single-File.sh $file /opt/tfcc/ucs/web/htdocs/images/public_signup_logos/. tfccapp 775 "" $servers
   ;;
  TOMCAT1 )
    echo "Deploying TOMCAT1 WARs"
     getServers $platform "APP"
     echo "T1 SERVERS: $servers"
    . $scriptPath/deploy-Single-File.sh $file /opt/tfcc/ucs/tomcat1/webapps/. tfccsrv 775 "$service" $servers
    ;;
  TOMCAT2 )
    echo "Deploying TOMCAT2 WARs"
    getServers $platform "APP"
    echo "T2 SERVERS: $servers"
   . $scriptPath/deploy-Single-File.sh $file /opt/tfcc/ucs/tomcat2/webapps/. tfccsrv 775 "$service" $servers
  ;;
  JAVA_PROPERTY )
    echo "Deploying JAVA PROPERTY File"
    getServers $platform "APP"
    echo "JP SERVERS: $servers"
   . $scriptPath/deploy-Single-File.sh $file /opt/tfcc/ucs/etc/. tfccapp 775 "$service" $servers
  ;;
  * ) echo "INVALID TASK FOUND: $task"
      usage
      exit 1
 esac
fi
