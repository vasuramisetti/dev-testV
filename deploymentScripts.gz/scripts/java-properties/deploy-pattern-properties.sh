#!/bin/bash

if [ -z $2 ]; then 
echo "$0 <username> <ATL01|DEN06|PREPROD|CMH|DEN|BETA|TEST|BETALAB|DEVLAB> <pattern>";
exit
fi

ATL_SERVERS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com"
DEN06_SERVERS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"
PREPROD_SERVERS="esx-app05ucstest.cmh.tfcci.local esx-app06ucstest.cmh.tfcci.local"
CMH_SERVERS=""
DEN_SERVERS=""
BETA_SERVERS="esx-app07ucsbeta.cmh.tfcci.local"
DEV_SERVERS="myapp"
TEST_SERVERS=""
BETALAB_SERVERS=""
user=$1

prop_path="Production/$2"
if [ $2 = "BETA" ]; then
  servers=$BETA_SERVERS
  prop_path="Beta";
fi
if [ $2 = "TEST" ]; then
 servers=$TEST_SERVERS
 prop_path="Test";
fi
if [ $2 = "DEVLAB" ]; then
 servers=$DEV_SERVERS
 prop_path="Dev";
fi
if [ $2 = "DEN" ]; then
 servers=$DEN_SERVERS
fi
if [ $2 = "CMH" ]; then
 servers=$CMH_SERVERS
fi
if [ $2 = "PREPROD" ]; then
 servers=$PREPROD_SERVERS
 prop_path="Preprod"
fi
if [ $2 = "DEN06" ]; then
 servers=$DEN06_SERVERS
fi
if [ $2 = "ATL01" ]; then
 servers=$ATL_SERVERS
fi

pattern=""
if [ -z $3 ]; then
echo "Using No Pattern"
else 
echo "User Pattern: $3"
pattern=$3
fi

if [ "$(ls -A $prop_path/*.properties)" ]; then
 : # Do Nothing
else
 echo "Could not find directory! $prop_path"
 exit 1;
fi


for server in $servers; do 
 echo "Deploying properties to $server"
 echo "Created Deployment location"
 ssh -t $user@$server rm -r /opt/tfcc/ucs/deploy/$user/etc
 ssh -t $user@$server mkdir -p /opt/tfcc/ucs/deploy/$user/etc
 
 echo "Copying Files to Deployment location";
 scp $prop_path/$pattern*.properties deployOnServer.sh $user@$server:/opt/tfcc/ucs/deploy/$user/etc/.
 echo "Deploying Files to the server location"
 ssh -t $user@$server /opt/tfcc/ucs/deploy/$user/etc/deployOnServer.sh /opt/tfcc/ucs/deploy/$user/etc /opt/tfcc/ucs/etc/. tfccapp:tfcclog
 echo "Finished with $server"
done
