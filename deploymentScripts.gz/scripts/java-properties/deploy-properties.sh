#!/bin/bash

if [ -z $2 ]; then 
echo "$0 <username> <SWN01|DEN06|PREPROD|CMH|DEN|BETA|TEST|BETALAB|DEVLAB|QA> <APP_SERVERS|optional override>";
exit
fi

SWN_SERVERS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com"
DEN06_SERVERS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"
PREPROD_SERVERS="app-pre-1-ucs.utilities.west.com app-pre-2-ucs.utilities.west.com"
CMH_SERVERS=""
DEN_SERVERS=""
BETA_SERVERS="app-dev-1-ucs.utilities.west.com"
DEV_SERVERS="myapp"
TEST_SERVERS=""
BETALAB_SERVERS=""
QA_SERVERS="app-qa-1-ucs.utilities.west.com app-qa-2-ucs.utilities.west.com"

user=$1

prop_path="Production/$2"
if [ $2 = "BETA" ]; then
  servers=$BETA_SERVERS
  prop_path="Beta";
fi
if [ $2 = "TEST" ]; then
 servers=$TEST_SERVERS
 prop_path="Test";
fi
if [ $2 = "DEVLAB" ]; then
 servers=$DEV_SERVERS
 prop_path="Dev";
fi
if [ $2 = "DEN" ]; then
 servers=$DEN_SERVERS
fi
if [ $2 = "CMH" ]; then
 servers=$CMH_SERVERS
fi
if [ $2 = "PREPROD" ]; then
 servers=$PREPROD_SERVERS
 prop_path="Preprod"
fi
if [ $2 = "DEN06" ]; then
 servers=$DEN06_SERVERS
fi
if [ $2 = "SWN01" ]; then
 servers=$SWN_SERVERS
fi
if [ $2 = "QA" ]; then
 servers=$QA_SERVERS
 prop_path="QA";
fi

if [ -z $3 ]; then
echo "Using standard servers: $servers"
else 
echo "User overrided servers: $3"
servers=$3
fi

if [ "$(ls -A $prop_path/*.properties)" ]; then
 : # Do Nothing
else
 echo "Could not find directory! $prop_path"
 exit 1;
fi


for server in $servers; do 
 echo "Deploying properties to $server"
 echo "Created Deployment location"
 ssh -t $user@$server mkdir -p /opt/tfcc/ucs/deploy/$user/etc
 
 echo "Copying Files to Deployment location";
 scp $prop_path/*.properties deployOnServer.sh $user@$server:/opt/tfcc/ucs/deploy/$user/etc/.
 echo "Deploying Files to the server location"
 ssh -t $user@$server /opt/tfcc/ucs/deploy/$user/etc/deployOnServer.sh /opt/tfcc/ucs/deploy/$user/etc /opt/tfcc/ucs/etc/. tfccapp:tfcclog
 echo "Finished with $server"
done
