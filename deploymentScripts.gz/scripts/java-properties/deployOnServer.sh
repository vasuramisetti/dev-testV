#!/usr/bin/bash  
 
 # Setup Environment for this script
export PATH=$PATH:/opt/sfw/bin:/usr/sfw/bin:/usr/sbin
cd /opt/tfcc
#echo "1: $1"
#echo "2: $2"
#echo "3: $3"
#echo "4: $4"
sudo cp -rf $1/*.properties $2
sudo chown -R $3 $2
# delete the directory
rm -r $1