#! /bin/bash
################################################################
# TFCC Alert Manager ZIP Deployment
################################################################
export PATH=$PATH:/opt/sfw/bin:/usr/sfw/bin:/usr/sbin

SUDO="/opt/sfw/bin/sudo"
UNZIP="/usr/bin/unzip"

BETA_SERVERS="app-dev-1-ucs.utilities.west.com"
PREPROD_SERVERS="app-pre-1-ucs.utilities.west.com app-pre-2-ucs.utilities.west.com"

QA_SERVERS="app-qa-1-ucs.utilities.west.com app-qa-2-ucs.utilities.west.com"
PROD_SERVERS="app1ucs.cmh.tfcci.local app2ucs.cmh.tfcci.local app3ucs.cmh.tfcci.local app4ucs.cmh.tfcci.local"
DENVER_SERVERS="app1denucs.tfcci.local app2denucs.tfcci.local"

#SWN01_SERVERS="myapp"
#DEN06_SERVERS="myapp"

SWN01_SERVERS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com"
DEN06_SERVERS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"

NEXUS_SERVER=

TOMCAT_WEBAPP_DIR="java/"

WGET_LOCAL="wget --proxy=off"
WGET_REMOTE="/usr/local/bin/wget --proxy=off"

SERVICE_STOP_CMD="$SUDO /usr/sbin/svcadm disable -s "
SERVICE_START_CMD="$SUDO /usr/sbin/svcadm enable -s "

ARTIFACT_RELEASE_SERVER="http://artifacts.west.com/artifactory/libs-release/com/tfcci/ucs/managers"
ARTIFACT_SNAPSHOT_SERVER="http://artifacts.west.com/artifactory/libs-snapshot/com/tfcci/ucs/managers"

SCRIPT_PATH=`dirname "$BASH_SOURCE"`

VERSION_URL=
SNAPSHOT_TEMP_FILE="snapshot-maven-metadata.xml"
SNAPSHOT_TEMP_SCRIPT="snapshot-script.sh"
SNAPSHOT_XSLT="xsltproc $SCRIPT_PATH/snapshot.xslt"
VERSION_XSLT="xsltproc $SCRIPT_PATH/version.xslt"
VERSION_TEMP_FILE="maven-metadata.xml"
VERSION_TEMP_SCRIPT="version-script.sh"


# print usage info
function usage
{
  echo "usage: mgr_deployment.sh [-l] [-p] [-n] [-t] [-d] [-h]"
  echo "     -n | --non-interactive       non-interactive"
  echo "     -l | --location              deployment location [DEN06|SWN01|BETA|DEV|PREPROD]"
  echo "     -p | --project               project to deploy [ucs-web|...|all]"
  echo "     -d | --dir                   workspace directory [trunk|1.0.x|...] default: trunk"
  echo "     -s | --source                Zip file Source [target|nexus]"
  echo "     -m | --repository            '1' - RELEASE,  '2' - SNAPSHOT"
  echo "     -v | --version               Version to pull down if source is Nexus (not required for target)"
  echo "     -r | --restart               Restarts the manager"
  echo "     -u | --user                  The user to log onto the server as (example: domain login) defaults to whoami"
  echo "     -h | --help                  help print this usage"
}

##########################################
# Main
##########################################

# set defaults
interactive=1
from_target=0
platform=
project=
source=
source_text=
version=
target_dir_base="trunk"
restart=0
USER=$(whoami)
SERVER_BASE=/opt/tfcc/ucs
SCRIPT_PATH=`dirname "$BASH_SOURCE"`
DEPLOYMENT_LOCATION=$SERVER_BASE/java-managers
DEPLOYMENT_LOG_BASE=$SERVER_BASE/logs/java-managers
repository=
snapshot=

LOCAL_DEPLOY_DIR=.mgr-deployment

while [ "$1" != "" ]; do
    #echo $1
    case $1 in
        -l | --location )            shift
                                     platform=$1
                                     ;;
        -p | --project )             shift
                                     project=$1
                                     ;;
        -d | --dir )                 shift
                                     target_dir_base=$1
                                     ;;
        -n | --non-interactive )     interactive=0
                                     ;;
        -h | --help )                usage
                                     exit
                                     ;;
        -s | --source)               shift
                                     source=$1
                                     ;;
        -v | --version)              shift
                                     version=$1
                                     ;;
        -r | --restart)              restart=1
                                     ;;
        -m | --repository)           shift
                                     repository=$1
                                     ;;
        -u | --user)                 shift
                                     USER=$1;;
        * )                          usage
                                     exit 1
    esac
    shift
done


# set the target dir base
TARGET_DIR_BASE=$target_dir_base

VERSION_URL=$ARTIFACT_RELEASE_SERVER/$project/maven-metadata.xml
NEXUS_SERVER=$ARTIFACT_RELEASE_SERVER

SERVICES_TO_RESTART="";
ALL=0;


if [ $interactive = 1 ]; then
  ########################################
  # Interactive mode
  ########################################

  echo "Entering interactive mode..."

  # get USER
  echo "#############################################"
  echo "Which user are you using for the deployment?"
  echo "#############################################"
  echo "1) $USER"
  echo "2) Another User"
  echo "? "

  read -e useroption

  if [ $useroption = 2 ]; then
    echo "#############################################"
    echo "Please enter the user name you are going to"
    echo " use for the deployment"
    echo "#############################################"
    read -e USER
  fi

  # get platform
  echo "#############################################"
  echo "Which platform would you like to deploy to?"
  echo "#############################################"
  echo "1) Production CMH"
  echo "2) Production DEN"
  echo "3) QA"
  echo "4) Beta"
  echo "5) Preprod"
  echo "6) Production SWN01"
  echo "7) Production DEN05"
  echo "? "

  read -e platform

  # get project
  echo "#########################################"
  echo "Which project(s) would you like to deploy?"
  echo "#########################################"
  echo "1) CP Direct Email Manager"
  echo "2) -- deprecated -- Scheduled Wellness Check Manager"
  echo "3) WNG Outdial Manager"
  echo "4) Geoloader Manager"
  echo "5) TASS Credit Manager"
  echo "6) TASS SMS Auto-reply Manager"
  echo "7) WNG Results Manager"
  echo "8) SendGrid Email Manager"
  echo "9) Notification Results Manager"
  echo "10) SMS Manager WIMP/OPENMARKET"
  echo "11) WNG Consultant Manager"
  echo "all) all projects"
  echo "? "

  read -e project

  # get source
  echo "#########################################"
  echo "Where do you want to retreive the binarys from?"
  echo "#########################################"
  echo "1) From Target (Hudson)"
  echo "2) Nexus Respository"
  echo "? "

  read -e source


  if [ $source = 1 ]; then
     echo "#########################################"
     echo "Please type the target absolute path below."
     echo "#########################################"
     read -e TARGET_DIR_BASE
  fi
  if [ $source = 2 ]; then
    # get source
    echo "#########################################"
    echo "Do you want a SNAPSHOT or RELEASE?"
    echo "#########################################"
    echo "1) Release"
    echo "2) Snapshot"
    echo "? "

    read -e repository

    if [ $repository = 2 ]; then
      VERSION_URL=$ARTIFACT_SNAPSHOT_SERVER/$project/maven-metadata.xml
      NEXUS_SERVER=$ARTIFACT_SNAPSHOT_SERVER
      snapshot=1
    fi

    echo "Determining Available Versions"
    #echo "$WGET_LOCAL --quiet --output-document=$VERSION_TEMP_FILE $VERSION_URL"
    $WGET_LOCAL --quiet --output-document=$VERSION_TEMP_FILE $VERSION_URL
    #echo "$VERSION_XSLT $VERSION_TEMP_FILE > $VERSION_TEMP_SCRIPT"
    $VERSION_XSLT $VERSION_TEMP_FILE > $VERSION_TEMP_SCRIPT
    rm $VERSION_TEMP_FILE
    # get version
    echo "#########################################"
    echo "What version of the release are you deploying?"
    echo "#########################################"
    #read -e version
    source ./$VERSION_TEMP_SCRIPT
    rm $VERSION_TEMP_SCRIPT
  fi


  #######################################################################
  # End interactive mode
  #######################################################################

else
  echo "Entering non-ineractive mode...";
fi

case $platform in
"1" | "PROD")
  PLATFORM="Production"
  SERVERS=$PROD_SERVERS;;
"2" | "DEN")
  PLATFORM="Production"
  SERVERS=$DENVER_SERVERS;;
"3" | "PREPDOR")
  PLATFORM="QA/Test"
  SERVERS=$QA_SERVERS;;
"4" | "BETA")
  PLATFORM="Beta"
  SERVERS=$BETA_SERVERS;;
 "5" | "PREPROD")
  PLATFORM="Preprod"
  SERVERS=$PREPROD_SERVERS;;
 "6" | "SWN01")
  PLATFORM="SWN01"
  SERVERS=$SWN01_SERVERS;;
 "7" | "DEN06")
  PLATFORM="DEN06"
  SERVERS=$DEN06_SERVERS;;
*)
  echo "Invalid platform.  Exiting..."
  exit 1;
esac

case $project in
"1" | "tfc-cpdirect-manager")
  PROJECTS="tfc-cpdirect-manager"
  SERVICES_TO_RESTART="/ucs/app/bm32-java:default /ucs/app/bm502-java:default"
  ;;
"3" | "tfc-wng-outdial-manager")
  PROJECTS="tfc-wng-outdial-manager"
  SERVICES_TO_RESTART="/ucs/app/bm31-java:default /ucs/app/bm500-java:default /ucs/app/bm34-java:default /ucs/app/bm33-java:default /ucs/app/bm35-java:default"
  ;;
"4" | "tfc-geoloader-manager")
  PROJECTS="tfc-geoloader-manager"
  SERVICES_TO_RESTART="/ucs/app/alertgeold"
  ;;
"5" | "tass-credit-manager")
  PROJECTS="tass-credit-manager"
  SERVICES_TO_RESTART="/ucs/app/tass-credit"
  ;;
"6" | "tass-sms-autoreply-manager")
  PROJECTS="tass-sms-autoreply-manager"
  SERVICES_TO_RESTART="/ucs/app/tass-smsar"
  ;;
"7" | "tfc-wng-results-manager")
  PROJECTS="tfc-wng-results-manager"
  SERVICES_TO_RESTART="/ucs/app/wngorm1-java"
  ;;
"8" | "tfc-sendgrid-email-manager")
  PROJECTS="tfc-sendgrid-email-manager"
  SERVICES_TO_RESTART="/ucs/app/bm36-java /ucs/app/bm37-java /ucs/app/bm38-java /ucs/app/bm39-java"
  ;;
"9" | "tfc-notification-results-manager")
  PROJECTS="tfc-notification-results-manager"
  SERVICES_TO_RESTART="/ucs/app/nrm1"
  ;;
"10" | "tfc-sms-manager")
  PROJECTS="tfc-sms-manager"
  SERVICES_TO_RESTART="/ucs/app/bm40-java:default /ucs/app/bm41-java"
  ;;
"11" | "tfc-wng-consultant-manager")
  PROJECTS="tfc-wng-consultant-manager"
  SERVICES_TO_RESTART="/ucs/app/bm42-java"
  ;;
"all")
  PROJECTS="tfc-cpdirect-manager tfc-wng-outdial-manager tfc-geoloader-manager tass-credit-manager tass-sms-autoreply-manager tfc-wng-results-manager tfc-sendgrid-email-manager tfc-notification-results-manager tfc-sms-manager tfc-wng-consultant-manager"
  ALL=1
  SERVICES_TO_RESTART="/ucs/app/bm32-java /ucs/app/bm502-java /ucs/app/bm31-java /ucs/app/bm500-java /ucs/app/bm34-java /ucs/app/wngorm1-java /ucs/app/alertgeold /ucs/app/tass-smsar /ucs/app/tass-credit /ucs/app/bm36-java /ucs/app/bm37-java /ucs/app/bm38-java /ucs/app/bm39-java /ucs/app/nrm1 /ucs/app/bm40-java /ucs/app/bm41-java /ucs/app/bm42-java"
  ;;
*)
  echo "Invalid project.  Exiting..."
  exit 1;
esac

case $source in
"1" | "target")
  source_text="From Target"
  source=1
  ;;
"2" | "nexus")
  source_text="Nexus Respository"
  source=2
  ;;
*)
  echo "Invalid source.  Exiting..."
  exit 1;
esac


# confirm
echo "   "
echo "Actions to be performed: "
echo " Deploy to $PLATFORM"
echo "   PROJECTS: $PROJECTS"
echo "   USER: $USER"
echo "   SERVERS: $SERVERS"
echo "   Source: $source_text"
COMMANDLINE="-n -l $platform -u $USER -s $source -p $project"
if [ $source = 1 ]; then
echo "   TARGET: $TARGET_DIR_BASE"
COMMANDLINE="$COMMANDLINE -d $TARGET_DIR_BASE"
fi
if [ $source = 2 ]; then
echo "   VERSION: $version"
COMMANDLINE="$COMMANDLINE -m $repository -v $version"
fi
if [ $restart = 1 ]; then
echo "   RESTART: TRUE"
COMMANDLINE="$COMMANDLINE -r"
else
echo "   RESTART: FALSE"
fi

echo "CommandLine option equivalent: $0 $COMMANDLINE"

if [ $source = 2 ]; then
  if [ $repository = 2 ]; then
     VERSION_URL=$ARTIFACT_SNAPSHOT_SERVER/$project/maven-metadata.xml
     NEXUS_SERVER=$ARTIFACT_SNAPSHOT_SERVER
     snapshot=1
  fi
fi


if [ $interactive = 1 ]; then
  echo " Would you like to proceed? (Y/N)"

  read -e proceed
  case $proceed in
  "Y" | "y")
    echo "Proceeding.."
    ;;
  *)
    echo "Cancelled, Exiting..."
    exit 1
    ;;
  esac
fi
DEPLOYMENT_STAGING_LOCATION=$SERVER_BASE/deploy/$USER/java-manager
mkdir $LOCAL_DEPLOY_DIR;

echo "Retreiving All Manager Projects"
for p in $PROJECTS
  do
case $source in
    "1" )
      echo "Moving Target to staging";
      echo "$TARGET_DIR_BASE/ucs-managers/$p/target/$p-bin.zip $LOCAL_DEPLOY_DIR/."
      cp $TARGET_DIR_BASE/ucs-managers/$p/target/$p-bin.zip $LOCAL_DEPLOY_DIR/.
    ;;
    "2")
    fileRoot=""
    if [ $snapshot = 1 ]; then
      retrieval_version=`echo $version | cut -d'-' -f 1`
      echo " $WGET_LOCAL --quiet --output-document=$SNAPSHOT_TEMP_FILE $ARTIFACT_SNAPSHOT_SERVER/$p/$version/maven-metadata.xml"
      $WGET_LOCAL --quiet --output-document=$SNAPSHOT_TEMP_FILE $ARTIFACT_SNAPSHOT_SERVER/$p/$version/maven-metadata.xml
      echo "$SNAPSHOT_XSLT $SNAPSHOT_TEMP_FILE > $SNAPSHOT_TEMP_SCRIPT"
      cat $SNAPSHOT_TEMP_FILE
      $SNAPSHOT_XSLT $SNAPSHOT_TEMP_FILE > $SNAPSHOT_TEMP_SCRIPT
      source $SNAPSHOT_TEMP_SCRIPT;
      fileRoot="$p-$retrieval_version-$snapshot_file";
      rm $SNAPSHOT_TEMP_SCRIPT $SNAPSHOT_TEMP_FILE
      NEXUS_SERVER=$ARTIFACT_SNAPSHOT_SERVER
    else
      fileRoot="$p-$version"
    fi

      echo "ssh $USER@$a $WGET_REMOTE --output-document=$DEPLOYMENT_STAGING_LOCATION/$p-bin.zip  $NEXUS_SERVER/$p/$version/$fileRoot-bin.zip"
      $WGET_LOCAL --output-document=$LOCAL_DEPLOY_DIR/$p-bin.zip  $NEXUS_SERVER/$p/$version/$fileRoot-bin.zip
    ;;
esac
done

# Write a script to deploy all project and restart them if they are already started
echo "#!/usr/bin/bash" > managersDeploy.sh
echo "cd $DEPLOYMENT_STAGING_LOCATION/.." > managersDeploy.sh
if [ $restart = 1 ]; then
  echo "RESTART_SERVICE=\"\"" >> managersDeploy.sh
  echo "for s in $SERVICES_TO_RESTART; do" >> managersDeploy.sh
  echo " RESTART_CADIDATE=\`svcs \"\$s\" | grep online | cut -b 25-\`;"  >> managersDeploy.sh
  echo " if [ -n \"\$RESTART_CADIDATE\" ]; then" >> managersDeploy.sh
  echo "  RESTART_SERVICE=\$RESTART_SERVICE\" \"\$RESTART_CADIDATE" >> managersDeploy.sh
  echo " fi" >> managersDeploy.sh
  echo "done " >> managersDeploy.sh
  echo "if [ -n \"\$RESTART_SERVICE\" ]; then" >> managersDeploy.sh
  echo " echo \"Shutting down managers that are part of this deployment: \$RESTART_SERVICE\"" >> managersDeploy.sh
  echo " $SUDO /usr/sbin/svcadm disable -s \$RESTART_SERVICE" >> managersDeploy.sh
  echo "fi" >> managersDeploy.sh
fi
for p in $PROJECTS
  do
    echo "$SUDO $DEPLOYMENT_STAGING_LOCATION/mgr-deploy.sh $DEPLOYMENT_LOCATION $DEPLOYMENT_STAGING_LOCATION $DEPLOYMENT_LOG_BASE $p 0" >> managersDeploy.sh
  done
if [ $restart = 1 ]; then
  echo "if [ -n \"\$RESTART_SERVICE\" ]; then" >> managersDeploy.sh
  echo " echo \"Starting up managers that are part of this deployment: \$RESTART_SERVICE\"" >> managersDeploy.sh
  echo " $SUDO /usr/sbin/svcadm enable -s \$RESTART_SERVICE" >> managersDeploy.sh
  echo "fi" >> managersDeploy.sh
fi


# copy files from target directory
echo "Copying files from $source_text to pre-deployment locations on manager servers..."
for a in $SERVERS
do
  echo "Copying deployment script to server"
  ssh -t $USER@$a mkdir -p $DEPLOYMENT_STAGING_LOCATION
  scp $SCRIPT_PATH/mgr-deploy.sh $USER@$a:$DEPLOYMENT_STAGING_LOCATION/.
  scp managersDeploy.sh $USER@$a:$DEPLOYMENT_STAGING_LOCATION/.
  ssh -t $USER@$a chmod +x $DEPLOYMENT_STAGING_LOCATION/managersDeploy.sh
  for p in $PROJECTS
  do
    echo "Copying files from $LOCAL_DEPLOY_DIR/$p-bin.zip to $DEPLOYMENT_STAGING_LOCATION on manager servers..."
    scp $LOCAL_DEPLOY_DIR/$p-bin.zip $USER@$a:$DEPLOYMENT_STAGING_LOCATION/.
  done;

  ssh -t $USER@$a $DEPLOYMENT_STAGING_LOCATION/managersDeploy.sh
  ssh -t $USER@$a "cd /opt/tfcc/ucs; $SUDO rm -rf $DEPLOYMENT_STAGING_LOCATION"
done

# Removing Temporary Deployment Directory
rm -rf $LOCAL_DEPLOY_DIR
rm managersDeploy.sh

# exit
echo "Exiting...";
