#!/bin/bash

if [ -z $2 ]; then
echo "$0 <CMH|DEN|BETA|TEST> <APP_SERVERS|optional override>";
exit
fi

location=$1
servers=$2
prop_path="Production/$1"
if [ $1 = "BETA" ]; then
 prop_path="Beta";
fi
if [ $1 = "TEST" ]; then
 prop_path="Test";
fi

directories="tass-credit-manager tass-sms-autoreply-manager tfc-cpdirect-manager tfc-geoloader-manager tfc-wng-outdial-manager tfc-wng-consultant-manager"

for i in $servers; do

for dir in $directories; do
echo "Sending $dir.properties for $location to $i";
scp ../../../ucs-managers/$dir/property_files/$prop_path/$dir.properties sg@$i:etc/.

done;

done;
