#!/bin/bash
# print usage info
function usage
{
  echo "usage: $0 [-s] [-u]   Checks if NFS Mounts are present"
  echo "     -s | --server                REQUIRED - Server IE esx-app07ucstest.cmh.tfcci.local"
  echo "     -h | --help                    help print this usage"
  echo "     -u | --user                    Your username for deploying applications"
  echo "                                      Defaults to whoami"
}

if [ -z $1 ]; then 
echo "No parameters provided, please see usage below:"
usage
exit
fi

USERNAME=`whoami`
server=
USER=`whoami`

MOUNTS="nfs-files-atl01 nfs-files-den06 nfs-files-local-datacenter nfs-ucs-voice-atl01 nfs-ucs-voice-den06"
BASEDIR=/opt/tfcc/ucs/

while [ "$1" != "" ]; do
#    echo $1
    case $1 in
        -s | --server )            shift
                                     server=$1
                                     ;;                          
        -h | --help )                usage
                                     exit
                                     ;;
        -u | --user)                 shift
                                     USER=$1
                                     ;;        
        * )                          usage
                                     exit 1
    esac
    shift
done


if [ -z $server ]; then 
echo "No server provided!"
usage
exit
fi



echo "Checking NFS Directories: $server";
command="ls -l "
for nfsMount in $MOUNTS; do
 command=$command" $BASEDIR$nfsMount"
done;
echo "Testing Mounts on $server.  If there is a significate delay the NFS mount might be broken".
ssh -t $USER@$server $command;
echo "Testing COMPLETED for NFS Mountd on $server"
echo "End of Script"
