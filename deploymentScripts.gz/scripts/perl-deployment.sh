#! /bin/bash
################################################################
# UCS Perl Deployment
################################################################

export PATH=$PATH:/opt/sfw/bin:/usr/sfw/bin:/usr/sbin

SUDO="/opt/sfw/bin/sudo"
TAR="tar"
if test -f "/usr/sfw/bin/gtar"; then TAR="/usr/sfw/bin/gtar"; fi
SCRIPT_PATH=`dirname "$BASH_SOURCE"`
USER=$(whoami)
SERVER_PATH="/opt/tfcc/ucs"

SWN01_WEB_SERVERS="sun56.anprod.com sun59.anprod.com sun62.anprod.com sun65.anprod.com";
SWN01_APP_SERVERS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com";

DEN06_WEB_SERVERS="sun39.anprod.com sun42.anprod.com sun45.anprod.com sun48.anprod.com"
DEN06_APP_SERVERS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"

DEV_WEB_SERVERS="myweb"
DEV_APP_SERVERS="myapp";

LAB_WEB_SERVERS="web-pre-2-ucs.utilities.west.com"
LAB_APP_SERVERS="app-pre-2-ucs.utilities.west.com"

#BETA_WEB_SERVERS="web-dev-1-ucs.utilities.west.com"
BETA_WEB_SERVERS="web-dev-1-ucs.utilities.west.com web-dev-2-ucs.utilities.west.com"
BETA_APP_SERVERS="app-dev-1-ucs.utilities.west.com"

PREPROD_WEB_SERVERS="web-pre-1-ucs.utilities.west.com web-pre-2-ucs.utilities.west.com"
PREPROD_APP_SERVERS="app-pre-1-ucs.utilities.west.com app-pre-2-ucs.utilities.west.com"

QA_APP_SERVERS="app-qa-1-ucs.utilities.west.com app-qa-2-ucs.utilities.west.com"
QA_WEB_SERVERS="web-qa-1-ucs.utilities.west.com web-qa-2-ucs.utilities.west.com"

CMH_WEB_SERVERS="web01ucs.cmh.tfcci.local web02ucs.cmh.tfcci.local web03ucs.cmh.tfcci.local web04ucstest.cmh.tfcci.local";
CMH_APP_SERVERS="app1ucs.cmh.tfcci.local app2ucs.cmh.tfcci.local app3ucs.cmh.tfcci.local app4ucs.cmh.tfcci.local app5ucs.cmh.tfcci.local app6ucs.cmh.tfcci.local inet1file.cmh.tfcci.local inet2file.cmh.tfcci.local"

DEN_WEB_SERVERS="web1denucs.tfcci.local web2denucs.tfcci.local"
DEN_APP_SERVERS="app1denucs.tfcci.local app2denucs.tfcci.local inet1denfile.tfcci.local"

NEXUS_RELEASE_SERVER="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-releases/com/tfcci/ucs/ucs-perl"
NEXUS_SNAPSHOT_SERVER="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-snapshots/com/tfcci/ucs/ucs-perl"

SNAPSHOT_TEMP_FILE="snapshot-maven-metadata.xml"
SNAPSHOT_TEMP_SCRIPT="snapshot-script.sh"
SNAPSHOT_XSLT="xsltproc $SCRIPT_PATH/snapshot.xslt"

TOMCAT_WEBAPP_DIR="java/"

WGET_LOCAL="wget --proxy=off"

VERSION_XSLT="xsltproc $SCRIPT_PATH/version.xslt"
VERSION_RELEASE_URL="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-releases/com/tfcci/ucs/ucs-perl/maven-metadata.xml"
VERSION_SNAPSHOT_URL="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-snapshots/com/tfcci/ucs/ucs-perl/maven-metadata.xml"
VERSION_TEMP_FILE="maven-metadata.xml"
VERSION_TEMP_SCRIPT="version-script.sh"


# print usage info
function usage
{
  echo "usage: perl_deployment.sh [-l] [-p] [-n] [-r] [-s] [-v]"
  echo "     -n | --non-interactive       non-interactive"
  echo "     -l | --location              deployment location [QA|CMH|DEN|BETA|DEV]"
  echo "     -d | --dir                   workspace directory [trunk|1.0.x|...] default: trunk"
  echo "     -s | --source                Zip file Source [target|nexus]"
  echo "     -r | --repository            the type of repository [SNAPSHOT|RELEASE] default: RELEASE"
  echo "     -v | --version               Version to pull down if source is Nexus (not required for target)"
  echo "     -h | --help                  help print this usage"
  echo "     -u | --user                  The user to log onto the server as (example: domain login) defaults to whoami"
}

##########################################
# Main
##########################################

# set defaults
interactive=1
from_target=0
platform=
source=
source_text=
repository="RELEASE"
version=
target_dir_base="trunk"
app_servers=
web_servers=
snapshot=0;
project="ucs-perl"
result=0;

while [ "$1" != "" ]; do
    #echo $1
    case $1 in
        -l | --location )            shift
                                     platform=$1
                                     ;;
        -d | --dir )                 shift
                                     target_dir_base=$1
                                     ;;
        -n | --non-interactive )     interactive=0
                                     ;;
        -h | --help )                usage
                                     exit
                                     ;;
        -s | --source)               shift
                                     source=$1
                                     ;;
        -v | --version)              shift
                                     version=$1
                                     ;;
        -r | --repository)           shift
                                     repository=$1
                                     ;;
        -u | --user)                 shift
                                     USER=$1
                                     ;;
        * )                          usage
                                     exit 1
    esac
    shift
done


# set the target dir base
TARGET_DIR_BASE=$target_dir_base

if [ $interactive = 1 ]; then
  ########################################
  # Interactive mode
  ########################################
  
  echo "Entering interactive mode..."


  # get platform
  echo "#############################################"
  echo "Which user are you using for the deployment?"
  echo "#############################################"
  echo "1) $USER"
  echo "2) Another User"
  echo "? "

  read -e useroption
  
  if [ $useroption = 2 ]; then
    echo "#############################################"
    echo "Please enter the user name you are going to"
    echo " use for the deployment"
    echo "#############################################"
    read -e USER
  fi
  
  # get platform
  echo "#############################################"
  echo "Which platform would you like to deploy to?"
  echo "#############################################"
  echo "1) Production CMH"
  echo "2) Production DEN"
  echo "3) Preprod"
  echo "4) Beta CMH"
  echo "5) Developer"
  echo "6) Test Lab CMH"
  echo "7) Production SWN01"
  echo "8) Production DEN06"
  echo "9) QA "
  echo "? "

  read -e platform

  # get source
  echo "#########################################"
  echo "Where do you want to retreive the binarys from?"
  echo "#########################################"
  echo "1) From Target (Hudson)"
  echo "2) Nexus Respository"
  echo "? "

  read -e source
  
  if [ $source = 1 ]; then
     echo "#########################################"
     echo "Please type the target absolute path below."
     echo "#########################################"
     read -e TARGET_DIR_BASE
  fi
  if [ $source = 2 ]; then
    # get source
    echo "#########################################"
    echo "Do you want a SNAPSHOT or RELEASE?"
    echo "#########################################"
    echo "1) Release"
    echo "2) Snapshot"
    echo "? "
    read -e repository
    VERSION_URL=$VERSION_RELEASE_URL
    if [ $repository = 2 ]; then 
      VERSION_URL=$VERSION_SNAPSHOT_URL
      snapshot=1
    fi
  
    echo "Determining Available Versions"
    #echo "$WGET_LOCAL --quiet --output-document=$VERSION_TEMP_FILE $VERSION_URL"
    $WGET_LOCAL --quiet --output-document=$VERSION_TEMP_FILE $VERSION_URL
    #echo "$VERSION_XSLT $VERSION_TEMP_FILE > $VERSION_TEMP_SCRIPT"
    $VERSION_XSLT $VERSION_TEMP_FILE > $VERSION_TEMP_SCRIPT
    rm $VERSION_TEMP_FILE
    # get version
    echo "#########################################"
    echo "What version of the release are you deploying?"
    echo "#########################################"
    #read -e version
    source ./$VERSION_TEMP_SCRIPT
    rm $VERSION_TEMP_SCRIPT
  fi

  
  #######################################################################
  # End interactive mode
  #######################################################################
  
else
  echo "Entering non-ineractive mode...";
fi

case $platform in
"1" | "PROD")
  PLATFORM="Production CMD"
  web_servers=$CMH_WEB_SERVERS
  app_servers=$CMH_APP_SERVERS;;
"2" | "DEN")
  PLATFORM="Production DEN"
  web_servers=$DEN_WEB_SERVERS
  app_servers=$DEN_APP_SERVERS;;
"3" | "PREPROD")
  PLATFORM="Preprod"
  web_servers=$PREPROD_WEB_SERVERS
  app_servers=$PREPROD_APP_SERVERS;;
"4" | "BETA")
  PLATFORM="Beta Lab Production"
  web_servers=$BETA_WEB_SERVERS
  app_servers=$BETA_APP_SERVERS;;
"5" | "DEV")
  PLATFORM="Development"
  web_servers=$DEV_WEB_SERVERS
  app_servers=$DEV_APP_SERVERS;;
"6" | "LAB")
  echo "Deprecated platform.  Use Preprod instead. Exiting..."
  exit 1;;
"7" | "SWN01")
  PLATFORM="SWN01 Production"
  web_servers=$SWN01_WEB_SERVERS
  app_servers=$SWN01_APP_SERVERS;;
"8" | "DEN06")
  PLATFORM="DEN06 Production"
  web_servers=$DEN06_WEB_SERVERS
  app_servers=$DEN06_APP_SERVERS;;
"9" | "QA")
  PLATFORM="QA"
  web_servers=$QA_WEB_SERVERS
  app_servers=$QA_APP_SERVERS;;
*)
  echo "Invalid platform.  Exiting..."
  exit 1;
esac

case $source in
"1" | "target")
  source_text="From Target"
  source=1
  ;;
"2" | "nexus")
  source_text="Nexus Respository"
  source=2
  ;;
*)
  echo "Invalid source.  Exiting..."
  exit 1;
esac

if [ $source = 2 ]; then
  case $repository in
  "1" | "Release")
    VERSION_URL=$VERSION_RELEASE_URL
    snapshot=0
    ;;
  "2" | "Snapshot")
    VERSION_URL=$VERSION_SNAPSHOT_URL
    snapshot=1
    ;;
  *)
    echo "Invalid repository.  Exiting..."
    exit 1;
  esac
fi
  
 
# confirm
echo "   "
echo "Actions to be performed: "
echo " Deploy to $PLATFORM"
echo "   Deployment User: $USER"
echo "   Web Servers: $web_servers"
echo "   App Servers: $app_servers"
echo "   Source: $source_text"
if [ $source = 1 ]; then
  echo "   Target Directory: $TARGET_DIR_BASE"
  echo "CommandLine option equivalent: $0 -n -l $platform -d $TARGET_DIR_BASE -u $USER -s 1"
fi
if [ $source = 2 ]; then
echo "   Repository: $VERSION_URL"
echo "   Version: $version"
echo "CommandLine option equivalent: $0 -n -l $platform -u $USER -s 2 -r $repository -v $version"
fi



if [ $interactive = 1 ]; then
  echo " Would you like to proceed? (Y/N)"    

  read -e proceed
  case $proceed in
  "Y" | "y")
    echo "Proceeding.."
    ;;
  *)
    echo "Cancelled, Exiting..."
    exit 1
    ;;
  esac
fi

rm -rf deploy
mkdir -p deploy 

retrieval_version=$version;
fileRoot="ucs-perl";
# Pull down tar files form the repository
NEXUS_SERVER=$NEXUS_RELEASE_SERVER
if [ $snapshot = 1 ]; then 
  retrieval_version=`echo $version | cut -d'-' -f 1`
  echo " $WGET_LOCAL --quiet --output-document=$SNAPSHOT_TEMP_FILE $NEXUS_SNAPSHOT_SERVER/$version/maven-metadata.xml"
  $WGET_LOCAL --quiet --output-document=$SNAPSHOT_TEMP_FILE $NEXUS_SNAPSHOT_SERVER/$version/maven-metadata.xml
  echo "$SNAPSHOT_XSLT $SNAPSHOT_TEMP_FILE > $SNAPSHOT_TEMP_SCRIPT"
  cat $SNAPSHOT_TEMP_FILE
  $SNAPSHOT_XSLT $SNAPSHOT_TEMP_FILE > $SNAPSHOT_TEMP_SCRIPT
  source $SNAPSHOT_TEMP_SCRIPT;
  fileRoot="$fileRoot-$retrieval_version-$snapshot_file";
  rm $SNAPSHOT_TEMP_SCRIPT $SNAPSHOT_TEMP_FILE
  NEXUS_SERVER=$NEXUS_SNAPSHOT_SERVER
else
  fileRoot="$fileRoot-$retrieval_version"
fi


# if target is selected we need to get it from the given target
if [ $source = 1 ]; then 
  fileRoot="ucs-perl";
  if test -f $TARGET_DIR_BASE/app-package.tar.gz; then
    echo "Found appserver tar.gz.";
  else
    echo "Could not find $TARGET_DIR_BASE/app-package.tar.gz Was it an absolute path to where you built the perl?";
    exit
  fi
    if test -f $TARGET_DIR_BASE/web-package.tar.gz; then
    echo "Found Webserver tar.gz.";
  else
    echo "Could not find $TARGET_DIR_BASE/web-package.tar.gz  Was it an absolute path to where you built the perl?";
    exit
  fi
  cp $TARGET_DIR_BASE/app-package.tar.gz deploy/$fileRoot.app.tar.gz
  cp $TARGET_DIR_BASE/web-package.tar.gz deploy/$fileRoot.web.tar.gz
else
  echo $NEXUS_SERVER/$version/$fileRoot
  $WGET_LOCAL --output-document=deploy/$fileRoot.app.tar.gz  $NEXUS_SERVER/$version/$fileRoot.app.tar.gz
  $WGET_LOCAL --output-document=deploy/$fileRoot.web.tar.gz  $NEXUS_SERVER/$version/$fileRoot.web.tar.gz
fi


# copy files from target directory
echo "Copying files to Web Servers: $web_servers"
for a in $web_servers
do
echo "Copying $fileRoot.web.tar.gz to $a"
ssh $USER@$a mkdir -p $SERVER_PATH/deploy/$USER
scp deploy/$fileRoot.web.tar.gz $USER@$a:$SERVER_PATH/deploy/$USER/web-package.new.tar.gz;
if [ $? -ne 0 ]; then
  echo "Unable to scp the file to the web server";
  exit;
fi
echo "Untaring package files (non-deployment)"
ssh -t $USER@$a /usr/sfw/bin/gtar -C $SERVER_PATH/deploy/$USER --overwrite -xzf $SERVER_PATH/deploy/$USER/web-package.new.tar.gz;
done
echo "Copying files to App Servers: $app_servers"
for a in $app_servers
do
echo "Copying $fileRoot.app.tar.gz to $a"
ssh $USER@$a mkdir -p $SERVER_PATH/deploy/$USER
scp deploy/$fileRoot.app.tar.gz $USER@$a:$SERVER_PATH/deploy/$USER/app-package.new.tar.gz;
if [ $? -ne 0 ]; then
  echo "Unable to scp the file to the app server";
  exit;
fi
echo "Untaring package files (non-deployment)"
ssh -t $USER@$a /usr/sfw/bin/gtar -C $SERVER_PATH/deploy/$USER --overwrite -xzf $SERVER_PATH/deploy/$USER/app-package.new.tar.gz;
done

echo "Files now on every machine, now to start deployment process.".

for a in $app_servers
do
	ssh -t $USER@$a $SERVER_PATH/deploy/$USER/scripts/app-predeploy.sh
	ssh -t $USER@$a $SERVER_PATH/deploy/$USER/scripts/app-deploy.sh
	ssh -t $USER@$a $SERVER_PATH/deploy/$USER/scripts/app-postdeploy.sh
done

for a in $web_servers
do
 ssh -t $USER@$a $SERVER_PATH/deploy/$USER/scripts/web-predeploy.sh;
 # To perserve the ownership of the directories we need to sudo
 ssh -t $USER@$a /opt/sfw/bin/sudo $SERVER_PATH/deploy/$USER/scripts/web-deploy.sh;
 ssh -t $USER@$a $SERVER_PATH/deploy/$USER/scripts/web-postdeploy.sh;
done


# exit
echo "Exiting...";
