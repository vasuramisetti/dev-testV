#!/bin/bash

SWN01_WEBS="sun56.anprod.com sun59.anprod.com sun62.anprod.com sun65.anprod.com";
SWN01_APPS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com";

SWN01_INETS=""
SWN01_ADMS=""

PERL=perl
SOL_PERL=/usr/local/bin/perl

DEN06_APPS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"
DEN06_WEBS="sun39.anprod.com sun42.anprod.com sun45.anprod.com sun48.anprod.com"
DEN06_INETS=""
DEN06_ADMS=""

PREPROD_APPS="app-pre-1-ucs.utilities.west.com app-pre-2-ucs.utilities.west.com"
PREPROD_WEBS="esx-web05ucstest.cmh.tfcci.local esx-web06ucstest.cmh.tfcci.local"
PREPROD_INETS=""
PREPROD_ADMS=""

BETA_APPS="app-dev-1-ucs.utilities.west.com"
BETA_WEBS=""
BETA_INETS=""
BETA_ADMS=""

QA_APPS="app-qa-1-ucs.utilities.west.com app-qa-2-ucs.utilities.west.com"
QA_WEBS="web-qa-1-ucs.utilities.west.com web-qa-2-ucs.utilities.west.com"
QA_INETS=""
QA_ADMS=""

APPS="myapp"
WEBS="myapp"
INETS=""
ADMS=""

SOL9="0";
SERVER_NAME=
LAST_PARAM=
SCRIPT_CONFIG_DIRECTORY=""

if [ -z $2 ]; then 
echo "$0 <USERNAME> <SWN01|DEN06|PREPROD|QA|BETA|DEV> <Stand Alone Scripts only Y/N> <APP> <WEB> <INET> <ADM>";
exit
fi

if [ `uname` = "SunOS" ]; then
PERL=$SOL_PERL
echo "SunOS Detected. Using $SOL_PERL"
fi

if [ $2 = "SWN01" ]; then
APPS=$SWN01_APPS
WEBS=$SWN01_WEBS
INETS=$SWN01_INETS
ADMS=$SWN01_ADMS
SCRIPT_CONFIG_DIRECTORY="scripts/Production/SWN01"
fi
if [ $2 = "DEN06" ]; then
APPS=$DEN06_APPS
WEBS=$DEN06_WEBS
INETS=$DEN06_INETS
ADMS=$DEN06_ADMS
SCRIPT_CONFIG_DIRECTORY="scripts/Production/DEN06"
fi
if [ $2 = "PREPROD" ]; then
APPS=$PREPROD_APPS
WEBS=$PREPROD_WEBS
INETS=$PREPROD_INETS
ADMS=$PREPROD_ADMS
SCRIPT_CONFIG_DIRECTORY="scripts/Preprod"
fi
if [ $2 = "BETA" ]; then
APPS=$BETA_APPS
WEBS=$BETA_WEBS
INETS=$BATALAB_INETS
ADMS=$BETA_ADMS
SCRIPT_CONFIG_DIRECTORY="scripts/Beta"
fi
if [ $2 = "QA" ]; then
APPS=$QA_APPS
WEBS=$QA_WEBS
INETS=$QA_INETS
ADMS=$QA_ADMS
SCRIPT_CONFIG_DIRECTORY="scripts/QA"
fi

if [ $2 = "DEV" ]; then
APPS="myapp"
WEBS="myweb"
INETS=
ADMS=
SERVER_NAME=$4
LAST_PARAM=$5
fi



STAND_ALONE_SCRIPTS="";

if [ -z $3 ]; then
: # do nothing
else 
 if [ $3 = "Y" ]; then
echo "STAND ALONE SCRIPT ONLY"
STAND_ALONE_SCRIPTS="YES";
 fi
fi

echo "Creating PlatformConfig Files"


rm -rf app web mgr adm inet

mkdir -p app/etc/perlAppServer
cp deployOnServer.sh app/.
mkdir -p app/etc/perlManagerServer
mkdir -p inet/etc/perlManagerServer
cp deployOnServer.sh inet/.
mkdir -p web/etc/perlWebServer
cp deployOnServer.sh web/.
mkdir -p adm/etc
cp deployOnServer.sh adm/.

if [ -z "$APPS" ]; then
  echo "NO App Servers Providing Skipping PlatformConfig Creation for App Servers";
else 
  echo "Generating Manager PlatformConfig"
  $PERL gen_PlatformConfig.pl mgr $2 $SOL9 $SERVER_NAME $LAST_PARAM
  mv PlatformConfig.pm.mgr app/etc/perlManagerServer/PlatformConfig.pm
  echo "Generating App PlatformConfig"
  $PERL gen_PlatformConfig.pl app $2 $SOL9 $SERVER_NAME $LAST_PARAM
  mv PlatformConfig.pm.app app/etc/perlAppServer/PlatformConfig.pm
  cp tnsnames.ora app/etc/.
fi
if [ -z "$INETS" ]; then
  echo "NO Inet Servers Providing Skipping PlatformConfig Creation for Inet Servers";
else 
  echo "Generating Inet PlatformConfig"
  $PERL gen_PlatformConfig.pl inet $2 $SOL9 $SERVER_NAME $LAST_PARAM
  mv PlatformConfig.pm.inet inet/etc/perlManagerServer/PlatformConfig.pm
  cp tnsnames.ora inet/etc/.
fi
if [ -z "$WEBS" ]; then
  echo "NO Web Servers Providing Skipping PlatformConfig Creation for Web Servers";
else 
  echo "Generating Web PlatformConfig"
  $PERL gen_PlatformConfig.pl web $2 $SOL9 $SERVER_NAME $LAST_PARAM
  mv PlatformConfig.pm.web web/etc/perlWebServer/PlatformConfig.pm
fi
if [ -z "$ADMS" ]; then
  echo "NO Admin Servers Providing Skipping PlatformConfig Creation for Admin Servers";
else 
  echo "Generating Admin PlatformConfig"
  $PERL gen_PlatformConfig.pl adm $2 $SOL9 $SERVER_NAME $LAST_PARAM
  mv PlatformConfig.pm.adm adm/etc/PlatformConfig.pm
fi
echo "Generation Complete"

echo "PlatformConfig Files Created"

DEPLOYMENT_LOCATION=/opt/tfcc/ucs/deploy/$1
SERVER_LOCATION=/opt/tfcc/ucs



echo "BEING PlatformConfig DEPLOYMENT"

if [ -z "$APPS" ]; then
  echo "Skipping App servers, Nothing to deploy."
else
  echo "Deploying Appservers"
  for server in $APPS; do
    echo "Deploying $server config files"
    ssh -t $1@$server mkdir -p $DEPLOYMENT_LOCATION
    if [ -z "$STAND_ALONE_SCRIPTS" ]; then
      scp -r app $1@$server:$DEPLOYMENT_LOCATION/.
    else 
     ssh -t $1@$server mkdir -p $DEPLOYMENT_LOCATION/app/etc
     scp -r app/deployOnServer.sh $1@$server:$DEPLOYMENT_LOCATION/app/.
    fi
    if [ -z "$SCRIPT_CONFIG_DIRECTORY" ]; then
      echo "No other perl configuration found to load. $SCRIPT_CONFIG_DIRECTORY ";
    else 
      echo "Deploying other perl configurations found in $SCRIPT_CONFIG_DIRECTORY."
      scp $SCRIPT_CONFIG_DIRECTORY/* $1@$server:$DEPLOYMENT_LOCATION/app/etc/.
    fi
    ssh -t $1@$server $DEPLOYMENT_LOCATION/app/deployOnServer.sh $DEPLOYMENT_LOCATION/app/etc $SERVER_LOCATION/app/. tfccapp:tfcclog
  done;
fi


if [ -z "$STAND_ALONE_SCRIPTS" ]; then
  if [ -z "$WEBS" ]; then
    echo "Skipping Web servers, Nothing to deploy."
  else
    echo "Deploying WebServers"
    for server in $WEBS; do
      echo "Deploying $server config files"
      ssh -t $1@$server mkdir -p $DEPLOYMENT_LOCATION
      scp -r web $1@$server:$DEPLOYMENT_LOCATION/.
      ssh -t $1@$server $DEPLOYMENT_LOCATION/web/deployOnServer.sh $DEPLOYMENT_LOCATION/web/etc $SERVER_LOCATION/web/. tfccsrv:tfcclog
    done;
  fi

  if [ -z "$INETS" ]; then
    echo "Skipping Inet servers, Nothing to deploy."
  else
    echo "Deploying INET Servers"
    for server in $INETS; do
      echo "Deploying $server config files"
      ssh -t $1@$server mkdir -p $DEPLOYMENT_LOCATION
      scp -r inet $1@$server:$DEPLOYMENT_LOCATION/.
      ssh -t $1@$server $DEPLOYMENT_LOCATION/inet/deployOnServer.sh $DEPLOYMENT_LOCATION/inet/etc $SERVER_LOCATION/app/. tfccapp:tfcclog
    done;
  fi

  if [ -z "$ADM" ]; then
    echo "Skipping Admin servers, Nothing to deploy."
  else
    echo "Deploying Admin Web Servers"
      for server in $ADM; do
      echo "Deploying $server config files"
      ssh -t $1@$server mkdir -p $DEPLOYMENT_LOCATION
      scp -r adm $1@$server:$DEPLOYMENT_LOCATION/.
      ssh -t $1@$server $DEPLOYMENT_LOCATION/adm/deployOnServer.sh $DEPLOYMENT_LOCATION/adm/etc $SERVER_LOCATION/app tfccsrv:tfcclog
    done;
  fi
fi
echo "END PlatformConfig DEPLOYMENT"

echo "Cleaning Up Configurations"

rm -rf app adm inet web

echo "Clean up Completed"
