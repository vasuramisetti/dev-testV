#!/usr/bin/bash
 

echo "$1 - From "
echo "$2 - To"
echo "$3 - Ownership"
deployFrom=$1
deployTo=$2
ownership=$3

 # Setup Environment for this script
export PATH=$PATH:/opt/sfw/bin:/usr/sfw/bin:/usr/sbin
cd /opt/tfcc
sudo cp -rf $deployFrom $deployTo
sudo chown -R $ownership $deployTo/etc

rm -rf $deployFrom/../deployOnServer.sh $deployFrom 
