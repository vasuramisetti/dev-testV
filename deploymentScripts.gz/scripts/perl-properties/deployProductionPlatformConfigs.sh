CMH_SOL10_APPS="app1ucs.cmh.tfcci.local app2ucs.cmh.tfcci.local app5ucs.cmh.tfcci.local app6ucs.cmh.tfcci.local"

CMH_SOL10_INET="inet1file.cmh.tfcci.local inet2file.cmh.tfcci.local"

CMH_SOL9_APPS="app3ucs.cmh.tfcci.local app4ucs.cmh.tfcci.local"

CMH_SOL10_WEBS="web01ucs.cmh.tfcci.local web02ucs.cmh.tfcci.local web03ucs.cmh.tfcci.local web04ucs.cmh.tfcci.local"


DEN_SOL10_APPS="app1denucs.tfcci.local app2denucs.tfcci.local"

DEN_SOL10_INET="inet1denfile.tfcci.local"

DEN_SOL10_WEBS="web1denucs.tfcci.local web2denucs.tfcci.local"

if [ -z $1 ]; then 
echo "$0 <CMH|DEN>";
exit
fi

if [ $1 = "CMH" ]; then

echo "BEING CMH PLATFORMCONFIG DEPLOYMENT"

echo "Deploying Solaris 10 CMH Appservers"
for server in $CMH_SOL10_APPS; do
echo "Deploying $server config files"
scp -r sol10app/* phoenix@$server:.
#scp ../../appserver/conf/startup.pl.app10 phoenix@$server:soapd/conf/startup.pl
done;

echo "Deploying Solaris 10 CMH InetServers"
for server in $CMH_SOL10_INET; do
echo "Deploying $server config files"
scp -r sol10inet/* phoenix@$server:.
done;

echo "Deploying Solaris 9 CMH Appservers"
for server in $CMH_SOL9_APPS; do
echo "Deploying $server config files"
scp -r sol9app/* phoenix@$server:.
#scp ../../appserver/conf/startup.pl.app9 phoenix@$server:soapd/conf/startup.pl
done;

echo "Deploying Solaris 10 CMH WebServers"
for server in $CMH_SOL10_WEBS; do
echo "Deploying $server config files"
scp -r web/* ucs2@$server:.
#scp ../../webserver/conf/startup.pl ucs2@$server:httpd/conf/startup.pl
done;

echo "END CMH PLATFORMCONFIG DEPLOYMENT"
fi

if [ $1 = "DEN" ]; then
echo "BEING DEN PLATFORMCONFIG DEPLOYMENT"

echo "Deploying Solaris 10 DEN Appservers"
for server in $DEN_SOL10_APPS; do
echo "Deploying $server config files"
scp -r denApp/* phoenix@$server:.
#scp ../../appserver/conf/startup.pl.app10 phoenix@$server:soapd/conf/startup.pl
done;

echo "Deploying Solaris 10 DEN InetServers"
for server in $DEN_SOL10_INET; do
echo "Deploying $server config files"
scp -r denApp/* phoenix@$server:.
done;

echo "Deploying Solaris 10 DEN WebServers"
for server in $DEN_SOL10_WEBS; do
echo "Deploying $server config files"
scp -r webDen/* ucs2@$server:.
#scp ../../webserver/conf/startup.pl ucs2@$server:httpd/conf/startup.pl
done;

echo "END DEN PLATFORMCONFIG DEPLOYMENT"
fi
