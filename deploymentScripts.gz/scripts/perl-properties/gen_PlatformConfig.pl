#!/usr/local/bin/perl
use strict;

use Text::Template;

use constant CALL_DEBUGGING => {
                                   "swn01"     => "NO",
                                   "den06"     => "NO",
                                   prod        => "NO",
                                   prodden     => "NO",
                                   preprod     => "YES",
                                   qa          => "YES",
								                   vxml_qa     => "YES",
                                   training    => "YES",
                                   beta        => "YES",
                                   dev         => "YES",
                                   devlab      => "YES",
                              };

use constant LOG_ALL => 99;
use constant LOG_DEBUG_PARAMS => 5;
use constant LOG_DEBUG => 4;
use constant LOG_INFO => 3;
use constant LOG_WARNING => 2;
use constant LOG_ERROR => 1;

use constant CORE_LOGLEVEL => {
                                   "swn01"     => LOG_INFO,
                                   "den06"     => LOG_INFO,
                                   prod        => LOG_INFO,
                                   prodden     => LOG_INFO,
                                   preprod     => LOG_INFO,
                                   qa          => LOG_INFO,
								                   vxml_qa     => LOG_INFO,
                                   training    => LOG_INFO,
                                   beta        => LOG_DEBUG,
                                   dev         => LOG_ALL,
                                   devlab      => LOG_ALL,
                              };
                              
use constant APP_LOGLEVEL => {
                                   "swn01"     => LOG_INFO,
                                   "den06"     => LOG_INFO,
                                   prod        => LOG_INFO,
                                   prodden     => LOG_INFO,
                                   preprod     => LOG_INFO,
								                   vxml_qa     => LOG_INFO,
                                   qa          => LOG_INFO,
                                   training    => LOG_INFO,
                                   beta        => LOG_DEBUG,
                                   dev         => LOG_ALL,
                                   devlab      => LOG_ALL,
                              };


# TMP DIRECTORIES For each type of server file. For the new datacenters
use constant TMP_DIRECTORY     => {
                                    adm  => '/opt/tfcc/ucs/tmp',
                                    app  => '/opt/tfcc/ucs/tmp',
                                    inet => '/opt/tfcc/ucs/tmp',
                                    mgr  => '/opt/tfcc/ucs/tmp',
                                    web  => '/opt/tfcc/ucs/tmp'
                                  };

# TMP DIRECTORIES For each type of server file. For CMH and DEN 
use constant LEGACY_TMP_DIRECTORY => {
                                    adm  => '/home/sg/tmp',
                                    app  => '/home/sg/tmp',
                                    inet => '/home/sg/tmp',
                                    mgr  => '/home/sg/tmp',
                                    web  => '/home/sg/tmp'
                                  };

# BASE DIRECTORIES For each type of server file. For the new datacenters
use constant BASE_DIRECTORY     => {     inet => '/opt/tfcc/ucs/app',
                                         app  => '/opt/tfcc/ucs/app',
                                         web  => '/opt/tfcc/ucs/web',
                                         adm  => '/opt/tfcc/ucs/web',
                                         mgr  => '/opt/tfcc/ucs/app',
                                       };

# BASE Direcotries for each type of server file in the CMH and DEN datacenters
use constant LEGACY_BASE_DIRECTORY     => { app9 => '/usr/local/phoenix',
                                            inet => '/export/home/phoenix',
                                            app  => '/export/home/phoenix',
                                            web  => '/export/home/ucs2',
                                            adm  => '/export/home/ucs2',
                                            mgr  => '/export/home/phoenix',
                                          };

# Log file paths after base directory for each type of server in the new datacenters
use constant BASE_LOGDIRECTORY => { app  => '/logs/app',
                                    web  => '/logs/web',
                                    adm  => '/logs/web',        
                                    mgr  => '/logs/app',
                                    inet => '/logs/app'
                                 };
                                 
# Log file path after the base directory foreach type in the CMH and DEN datacenters
 use constant LEGACY_BASE_LOGDIRECTORY => {  app  => '/logs',
                                             web  => '/logs',
                                             adm  => '/logs',        
                                             mgr  => '/logs',
                                             inet => '/logs'
                                   };

# APPLICATION_BASE_DIRECTORY
#  If this is set logs use this instead of the base directory
use constant APPLICATION_BASE_DIRECTORY => {
                                      swn01   => "/opt/tfcc/ucs",
                                      den06   => "/opt/tfcc/ucs",
                                      dev     => "/opt/tfcc/ucs",
                                      qa      => "/opt/tfcc/ucs",
                                      beta    => "/opt/tfcc/ucs",
                                      preprod => "/opt/tfcc/ucs"
                                    };
                                   
                                   
# hash foreach type of deployment to set the base directories                                   
use constant BASE_DIRECTORIES => { "swn01"     => BASE_DIRECTORY,
                                   "den06"     => BASE_DIRECTORY,
                                   prod        => LEGACY_BASE_DIRECTORY,
                                   prodden     => LEGACY_BASE_DIRECTORY,
                                   preprod     => BASE_DIRECTORY,
                                   qa          => BASE_DIRECTORY,   
								                   vxml_qa     => BASE_DIRECTORY,
                                   training    => LEGACY_BASE_DIRECTORY,
                                   dev         => BASE_DIRECTORY,
                                   beta        => BASE_DIRECTORY
                               };
                               
# hash foreach type of deployment to set the temp directories                                   
use constant TMP_DIRECTORIES => {
                                  "swn01"     => TMP_DIRECTORY,
                                  "den06"     => TMP_DIRECTORY,
                                  prod        => LEGACY_TMP_DIRECTORY,
                                  prodden     => LEGACY_TMP_DIRECTORY,
                                  preprod     => TMP_DIRECTORY,
								                  vxml_qa     => TMP_DIRECTORY,
                                  qa          => TMP_DIRECTORY,
                                  training    => LEGACY_TMP_DIRECTORY,
                                  dev         => TMP_DIRECTORY,
                                  beta        => TMP_DIRECTORY
                               };
                               
# hash foreach type of archive base directory (same as previous for now)
use constant ARCHIVE_BASE_DIRECTORIES => BASE_DIRECTORIES;

# LOG DIRECTORIES BY TYPE of deployment
## Log Directories assume that BASE_DIRECTORIES value will be appended
use constant BASE_LOGDIRECTORIES => { "swn01"      => BASE_LOGDIRECTORY,
                                      "den06"      => BASE_LOGDIRECTORY,
                                      "dev"        => BASE_LOGDIRECTORY,
                                       prod        => LEGACY_BASE_LOGDIRECTORY,
                                       prodden     => LEGACY_BASE_LOGDIRECTORY,
                                       preprod     => BASE_LOGDIRECTORY,
									                     vxml_qa     => BASE_LOGDIRECTORY,
                                       qa          => BASE_LOGDIRECTORY,
                                       beta        => BASE_LOGDIRECTORY,
                                       training    => LEGACY_BASE_LOGDIRECTORY
                               };
                                  
# Location foreach admin site                                 
use constant ADMIN_BASE => { swn01   => "swn01",
                             den06   => "den06",
                             dev     => "dev",
                             prod    => "prod",
                             preprod => "test",
							               vxml_qa => "vxml_qa",
                             qa      => "qa",
                             beta    => "tademo",
                             prodden => "prod",
                             training => "train"
                           };

# air2web queue name                                 
use constant A2W_QUEUE_NAME => { 
                swn01       => "a2w-b300-prod",
                den06       => "a2w-b300-prod",
                beta        => "a2w-b300-beta",
                dev         => "a2w-b300-dev",
                prod        => "a2w-b300-prod",
                prodden     => "a2w-b300-prod",
                preprod     => "a2w-b300-qa",
				        vxml_qa     => "a2w-b300-qa",
                qa          => "a2w-b300-qa",
                training    => "a2w-b300-train"
};

# platform URLS
use constant PLATFORM_URL => {
                              swn01    => "ucs.tfcci.com",
                              den06    => "ucs.tfcci.com",
                              prod     => "ucs.tfcci.com",
                              prodden  => "ucs.tfcci.com",
                              preprod  => "ucstest.tfcci.com",
							                vxml_qa  => "ucstest.tfcci.com",
                              qa       => "ucsqa.tfcci.com",
                              beta  => "ucs-beta.cmh.tfcci.local",
                              training => "ucstraining.tfcci.com"
                            };

# Internal Bureau Specific URL
# if not set use PLATFORM URL
#  This should be pointed to a load balancer
use constant INTERNAL_BUREAU_URL  => {
                                   swn01     => "10.28.101.73",
                                   den06     => "10.70.192.46", 
                                   beta      => "10.70.4.93",
								                   test      => "10.70.192.75",
								                   preprod   => "10.70.192.75",
												           vxml_qa   => "10.70.192.75",
                                   qa        => "10.70.4.72",
                                 };

# External Bureau IP Address
# This ip addresses are specific per platform 
use constant EXTERNAL_IP_URL => {
                                    swn01    => "75.78.124.88",  # ucs-nossl-swn01.tfcci.com
                                    den06    => "75.78.176.81",  # ucs-nossl-den06.tfcci.com
                                    preprod  => "75.78.178.157", # tfccalert-test.tfcci.com
									                  vxml_qa  => "75.78.178.157", # tfccalert-test.tfcci.com
                                    qa       => "10.70.4.72", # tfccalert-qa.tfcci.com
                                    beta     => "74.113.200.197"  # ucsbeta.tfcci.com
                                 };

# External Bureau Specfic URL 
#  if not set use Platform URL 
use constant EXTERNAL_BUREAU_URL  => {
                                        swn01    => "ucs-nossl-swn01.tfcci.com",
                                        den06    => "ucs-nossl-den06.tfcci.com",
										                    test     => "tfccalert-test.tfcci.com",
										                    preprod  => "tfccalert-test.tfcci.com",
															          vxml_qa  => "tfccalert-test.tfcci.com",
                                        qa  => "tfccalert-qa.tfcci.com",
                                        beta  => "ucs-beta.cmh.tfcci.local"
                                     };
                                     
# External Bureau Specfic URL 
#  if not set use Platform URL 
use constant EXTERNAL_SSL_BUREAU_URL  => {
                                          swn01    => "ucs.tfcci.com",
                                          den06    => "ucs.tfcci.com",
                                          preprod  => "ucstest.tfcci.com",
									                    	  vxml_qa  => "ucstest.tfcci.com",
                                          beta  => "ucs-beta.cmh.tfcci.local"
                                          };
                                          
# WSO2 URLS
use constant WSO2_URL => {
                              swn01    => "http://wicclientinterface:8280", # in hosts file on Holly boxes
                              den06    => "http://wicclientinterface:8280",,
                              prod     => "http://wicclientinterface:8280",,
                              prodden  => "http://wicclientinterface:8280",,
                              preprod  => "http://10.27.131.70:8280",  # pre-prod ESB, holly can't find in DNS
							                vxml_qa  => "http://10.27.131.70:8280",  # pre-prod ESB, holly can't find in DNS
                              	   qa  => "http://10.27.131.70:8280",  # pre-prod ESB, holly can't find in DNS
                                 beta  => "http://10.27.131.70:8280",
                              training => "http://10.27.131.70:8280"
                            };
														
# IDS HOSTS
use constant IDS_HOST => {
                              swn01     => "10.28.101.73",
															den06     => "10.70.192.46", 
                              beta      => "10.70.4.93",
								              test      => "10.70.192.75",
								              preprod   => "10.70.192.75",
											        vxml_qa   => "10.70.192.75",
                              qa        => "10.70.4.72",
                            };
                            
use constant MAP_SERVER   => { swn01    => "atl01vanmap01.anprod.com",
                               den06    => "den06vanmap01.anprod.com", 
                               prod     => "map2",
                               prodden  => "map1den",
                               preprod  => "cmh01anmaptst01.anprod.com",
							                 vxml_qa  => "cmh01anmaptst01.anprod.com",
                               beta     => "cmh01anmaptst01.anprod.com",
                               qa       => "den06devmap01.utilities.west.com",
                               training => "map2test",
                               dev   => "cmh01anmaptst01.anprod.com",
                               };
use constant MQ_SERVER    => { 
                               swn01    => "sun77.anprod.com",
                               den06    => "sun90.anprod.com",
                               prod     => "app2ucs.cmh.tfcci.local",
                               prodden  => "app2denucs.tfcci.local",
                               vxml_qa  => "app-pre-1-ucs.utilities.west.com",
                               qa       => "app-qa-1-ucs.utilities.west.com",
                               beta     => "app-dev-1-ucs.utilities.west.com",
                               training => "appintr1.cmh.tfcci.local",
                               dev   => "myapp",
                             };
use constant MQ_PORT        => {
                               swn01    => "5670",
                               den06    => "5670",
                               };
                               
                             
use constant PAGE_SERVER  => { 
                               swn01      => "page-tfcc.anprod.com",
                               den06      => "page-tfcc.anprod.com",
                               prod       => "page.tfcc.com",
                               prodden    => "page.tfcc.com",
                               preprod    => "pagedev.tfcc.com",
							                 vxml_qa    => "pagedev.tfcc.com",
                               qa         => "pagedev.tfcc.com",
                               beta       => "pagedev.tfcc.com",
                               training   => "pagedev.tfcc.com",
                               dev        => "DEV-NO-EMAIL",
                               };                              

use constant SOAP_SERVER  => { 
                               swn01    => "ucsapp-atl01-f5-8080.anprod.com",
                               den06    => "ucsapp-den06-f5-8080.anprod.com",
                               prod     => "app3ucs.cmh.tfcci.local",
                               prodden  => "app2denucs.tfcci.local",
                               beta     => "app-dev-1-ucs.utilities.west.com",
                               training => "appintr1.cmh.tfcci.local",
                               preprod   => "10.70.192.75",
							                 vxml_qa   => "10.70.192.75",
                               qa        => "app-qa-1-ucs.utilities.west.com",
                               dev   => "myapp"
                              };
                              
use constant ADM_SOAP_SERVER  => { 
                                   swn01    => "ucsapp-atl01-f5-8080.anprod.com",
                                   den06    => "ucsapp-den06-f5-8080.anprod.com",
                                   prod     => "ucsapp-f5-8080.anprod.com",
                                   prodden  => "ucsapp-f5-8080.anprod.com",
                                   beta    => "app-dev-1-ucs.utilities.west.com",
                                   preprod   => "10.70.192.75",
								                   vxml_qa   => "10.70.192.75",
                                   qa        => "app-qa-1-ucs.utilities.west.com",
                                   training => "appintr1.cmh.tfcci.local",
                              };
                            
use constant DB           => {
                               swn01    => "atldb1p",
                               den06    => "lmtdb1p",
                               prod     => "db2p",
                               prodden  => "db3p",
                               preprod  => "dbtden",
							                 vxml_qa  => "dbtden",
                               qa       => "dendb1t",
                               beta     => "dbtden",
                               training => "db4t",
                               dev      => "esx1-vm7"
                             };

use constant DB_USER     => { 
                               swn01    => "ucs_appu",
                               den06    => "ucs_appu",
                               prod     => "ucs_appu",
                               prodden  => "ucs_appu",
                               preprod  => "ucs_appu",
							                 vxml_qa  => "ucs_appu",
                               qa      => "ucs_appu",
                               beta     => "ucs_appu",
                               training => "ucs_appu",
                             };
use constant DB_PASSWORD => {  swn01    => "appu8ucs",
                               den06    => "appu8ucs",
                               prod     => "appu8ucs",
                               prodden  => "appu8ucs",
                               preprod  => "appu8ucs",
							                 vxml_qa  => "appu8ucs",
                               qa       => "appu8ucs",
                               beta     => "appu8ucs",
                               training => "appu8ucs",
                             };
use constant SCHEMA =>       {
                               swn01    => "ucs_user",
                               den06    => "ucs_user",
                               prod     => "ucs_user",
                               prodden  => "ucs_user",
                               preprod  => "ucs_user",
							                 vxml_qa  => "ucs_user",
                               qa       => "ucs_user",
                               beta     => "ucs5_user",
                               training => "ucs4_user",
                             };
use constant NO_REPL_SCHEMA => {
                               swn01    => "norep_user",
                               den06    => "norep_user",
                               prod     => "norep_user",
                               prodden  => "norep_user",
                               preprod  => "norep_user",
							                 vxml_qa  => "norep_user",
                               qa       => "norep_user",
                               beta     => "ucs5_user",
                               training => "norep4_user",
                             };

use constant ALERT_WS_SERVER => {
                               swn01    => "ucsapp-atl01-f5-8084.anprod.com:8084",
                               den06    => "ucsapp-den06-f5-8084.anprod.com:8084",
                               prod     => "localhost:8084",
                               prodden  => "localhost:8084",
                               preprod  => "10.70.192.75:8084",
							                 vxml_qa  => "10.70.192.75:8084",
                               qa       => "app-qa-1-ucs.utilities.west.com:8084",
                               training => "localhost:8084",
                               beta     => "localhost:8084",
                               dev      => "localhost:8084"
                              };

use constant TEP_WS_SERVER  => {
                               swn01    => "ucsapp-atl01-f5-8085.anprod.com:8085",
                               den06    => "ucsapp-den06-f5-8085.anprod.com:8085",
                               preprod  => "10.70.192.75:8085",
							                 vxml_qa  => "10.70.192.75:8085",
                               qa       => "app-qa-1-ucs.utilities.west.com:8085",
                               training => "localhost:8085",
                               beta     => "localhost:8085",
                               dev      => "esx-appucscitest.cmh.tfcci.local:8080/soap/tepSim.cgi?"
                               };
                              
use constant XO_APP_ID_TEST => "175301";
use constant XO_APP_ID_PROD => "1753";                             
use constant  XO_APP_ID => {
                            swn01    => XO_APP_ID_PROD,
                            den06    => XO_APP_ID_PROD, 
                            prod     => XO_APP_ID_PROD,
                            prodden  => XO_APP_ID_PROD,
                            preprod  => XO_APP_ID_TEST,
							              vxml_qa  => XO_APP_ID_TEST,
              	            qa       => XO_APP_ID_TEST,
                            beta     => XO_APP_ID_TEST,
                            training => XO_APP_ID_TEST,
                            dev      => XO_APP_ID_TEST,
                          };

                         
use constant OUTDIAL_PROG_ID_RANGE_SIZE => {
                                             swn01 => "5000000",
                                             den06 => "5000000",
                                             prod => "5000000",
                                             prodden => "5000000",
                                           };
                                           
use constant OUTDIAL_PROG_ID_RANGE_START  => {
                                             swn01 => "5000000",
                                             den06 => "5000000",
                                             prod => "5000000",
                                             prodden => "5000000",
                                           };

use constant SURVEY_AUDIO_DIRECTORY => { swn01 => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio",
                                         den06 => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio",
                                         preprod => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio",
										                     vxml_qa => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio",
                                         qa => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio",
                                         dev => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio",
                                         beta => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio",
                                         devlab => "/opt/tfcc/ucs/nfs-files-local-datacenter/recorded-audio" };

                
use constant PRIMARY_VOICE_DIRECTORY => { swn01 => "/opt/tfcc/ucs/nfs-ucs-voice-swn01",
                                          den06 => "/opt/tfcc/ucs/nfs-ucs-voice-den06",
                                          preprod => "/opt/tfcc/ucs/nfs-ucs-voice-a",
										                      vxml_qa => "/opt/tfcc/ucs/nfs-ucs-voice-a",
                                          qa => "/opt/tfcc/ucs/nfs-ucs-voice-qa-a",
                                          dev => "/opt/tfcc/ucs/nfs-ucs-voice-a",
                                          beta => "/opt/tfcc/ucs/nfs-ucs-voice-beta-a",
                                          devlab => "/opt/tfcc/ucs/nfs-ucs-voice-a" };
                                          
use constant SECONDARY_VOICE_DIRECTORY => { swn01 => "/opt/tfcc/ucs/nfs-ucs-voice-den06",
                                            den06 => "/opt/tfcc/ucs/nfs-ucs-voice-swn01",
                                            preprod => "/opt/tfcc/ucs/nfs-ucs-voice-b",
											                      vxml_qa => "/opt/tfcc/ucs/nfs-ucs-voice-b",
                                            qa => "/opt/tfcc/ucs/nfs-ucs-voice-qa-b",
                                            dev => "/opt/tfcc/ucs/nfs-ucs-voice-b",
                                            beta => "/opt/tfcc/ucs/nfs-ucs-voice-beta-b",
                                            devlab => "/opt/tfcc/ucs/nfs-ucs-voice-b"};
                                            
use constant PRIMARY_FILE_DIRECTORY => {  swn01 => "/opt/tfcc/ucs/nfs-files-swn01",
                                          den06 => "/opt/tfcc/ucs/nfs-files-den06",
                                          preprod => "/opt/tfcc/ucs/nfs-files-cmh01-a",
										                      vxml_qa => "/opt/tfcc/ucs/nfs-files-cmh01-a",
                                          qa => "/opt/tfcc/ucs/nfs-files-local-datacenter",
                                          dev => "/opt/tfcc/ucs/nfs-files-cmh01-a",
                                          beta => "/opt/tfcc/ucs/nfs-files-cmh01-beta-a",
                                          devlab => "/opt/tfcc/ucs/nfs-files-cmh01-a" };
                                          
use constant SECONDARY_FILE_DIRECTORY => { swn01 => "/opt/tfcc/ucs/nfs-files-den06",
                                           den06 => "/opt/tfcc/ucs/nfs-files-swn01",
                                           preprod => "/opt/tfcc/ucs/nfs-files-cmh01-b",
										   vxml_qa => "/opt/tfcc/ucs/nfs-files-cmh01-b",
                                           dev => "/opt/tfcc/ucs/nfs-files-cmh01-b",
                                           qa => "/opt/tfcc/ucs/nfs-files-local-datacenter",
                                           beta => "/opt/tfcc/ucs/nfs-files-cmh01-beta-b",
                                           devlab => "/opt/tfcc/ucs/nfs-files-cmh01-b"};

use constant CDR_NAMES => { beta => {    wng => 'DWNGUCS',
                                         xo  => 'DXOUCS',
                                         sms => 'DPDR',
                                         fax => 'DXFX',
                                         email => 'DEDR'},
                            default  =>  
                                       { wng => 'WNGUCS',
                                         xo  => 'XOUCS',
                                         sms => 'PDR',
                                         fax => 'XFX',
                                         email => 'EDR'},
                          };
use constant XO_JOB_NAME => { beta    => "TAD",
                              default => "UCS",};

use constant TRIGGER_FILE_DIRECTORY => { swn01 => "/opt/tfcc/ucs/app/support",
                                         den06 => "/opt/tfcc/ucs/app/support",
                                         preprod => "/opt/tfcc/ucs/app/support",
										                     vxml_qa => "/opt/tfcc/ucs/app/support",
                                         qa => "/opt/tfcc/ucs/app/support",
                                         dev => "/opt/tfcc/ucs/app/support",
                                         beta => "/opt/tfcc/ucs/app/support",
                                         training => "/export/home/phoenix/support",
                                         prod => "/export/home/phoenix/support"
                                       };

use constant WNG_TRANSFER_ROUTING_NUMBER_DEFAULT => "999000432";
use constant WNG_TRANSFER_ROUTING_NUMBER_PLATFORM => {
                                                       swn01 => '999040003',
                                                       den06 => '999040003',
                                                      };


die "Usage: perl gen_apache_configs.pl <app|mgr|web|adm> <swn01|den06|prod|prodden|preprod|training|beta|dev> <sol9> <workstation (devlab only)> <schema (devlab only)>\n"
    if (scalar @ARGV < 2);

my $type = lc(shift @ARGV);
my $profile = lc(shift @ARGV);
my $solaris9 = shift @ARGV;
my $machine_server = shift @ARGV;
my $setup_schema = shift @ARGV;

my $mgr_log = "";
$mgr_log = "mgr_"
  if $type eq "mgr" || $type eq "inet";
  
if ($profile eq "atl01") {
  $profile = "swn01";
}


my $schema = SCHEMA->{$profile};
my $db_user = DB_USER->{$profile};
my $db_password = DB_PASSWORD->{$profile};
my $norep_schema = NO_REPL_SCHEMA->{$profile};
my $platform_url = PLATFORM_URL->{$profile};

if ($profile eq "dev") {
  $schema=$setup_schema;
  if ($setup_schema eq "ucs3_user") {
    
    $db_user="ucs_appu";
    $db_password="appu8ucs";
    DB->{dev} = "db5t";
  } else {
    $db_user=$schema;
    $db_password=$schema;

  }
  $norep_schema=$setup_schema;
  $platform_url=$machine_server;
}


if (not defined $schema) {
  print "What is your Schema?\n";
  $schema = <>;
  chomp($schema);
}



if (not defined $norep_schema) {
  print "Do you want to use $schema as your non-replicated schema as well? Y or N\n";
  my $yn = <>;
  chomp($yn);
  if (uc($yn) eq "Y") {
    $norep_schema = $schema;
  } else {
    print "What is your Non Replicated Schema?\n";
    $norep_schema = <>;
    chomp($norep_schema);
  }
}



if ($type eq "web") {

 $db_user = "NOT_PROVIDED";
 $db_password = "NOT_PROVIDED";
}


if (not defined $db_user) {
   print "What DB username are you going to use?\n";
   $db_user = <>;
   chomp($db_user);
   
}

if (not defined $db_password) {
  print "What DB Password are you going to use?\n";
   $db_password = <>;
     chomp($db_password);
}

my $db = DB->{$profile};
if (not defined $db) {
  print "What database TNS name do you use?\n";
  $db = <>;
  chomp($db);
}

my $xo_app_id  = "NOTUSED";
if ($type eq "app" or $type eq "mgr" or $type eq "inet" ) {
 $xo_app_id = XO_APP_ID->{$profile};
}
$xo_app_id ||= "NOTUSED";

my $soap_server = SOAP_SERVER->{$profile};
my $page_server = PAGE_SERVER->{$profile};
$page_server ||= "pagedev.tfcc.com";
my $mq_server = MQ_SERVER->{$profile};
my $map_server = MAP_SERVER->{$profile};
$map_server ||= "map2test";


my $mq_port = "5672";
if (exists MQ_PORT->{$profile} and MQ_PORT->{$profile} ne "") {
  $mq_port = MQ_PORT->{$profile}
 }

my $admin_base = ADMIN_BASE->{$profile};
my $base_dir   = BASE_DIRECTORIES->{$profile}->{$type};
my $archive_base_dir =  ARCHIVE_BASE_DIRECTORIES->{$profile}->{$type};
# if we are doing a solaris 9 version then use itstead
if (defined $solaris9 and $solaris9 ne "") {
  if ($solaris9 eq "1") {
    $base_dir = BASE_DIRECTORIES->{$profile}->{'app9'};
    $archive_base_dir = ARCHIVE_BASE_DIRECTORIES->{$profile}->{'app9'};
  }
}
my $xmlParser = "XML::LibXML::SAX::Parser";
my $soapScript = "soapd.pl";
if ($type eq "inet") {
  $xmlParser = "";
}
if ($type eq "adm") {
  $soapScript = "admin.pl";
  $soap_server = ADM_SOAP_SERVER->{$profile};
}

if ($profile eq "dev" or $profile eq "cwhite") {
  if (not defined $platform_url) {
     print "What is the name of your Web Server?\n";
     $platform_url = <>;
     chomp($platform_url);

  }
  if (not defined $soap_server) {
     print "What is the name of your App Server?\n";
     $soap_server = <>;
     chomp($soap_server);

  }
  $mq_server = $soap_server;
}

# Internal URL should be the platform URL unless it is defined within the hash
my $internal_url = $platform_url;
if (exists INTERNAL_BUREAU_URL->{$profile} and defined INTERNAL_BUREAU_URL->{$profile} and INTERNAL_BUREAU_URL->{$profile} ne "") {
  $internal_url = INTERNAL_BUREAU_URL->{$profile};
} 

# exteneral URL should be the platform URL unless it is defined within the hash
my $external_url = $platform_url;
if (exists EXTERNAL_BUREAU_URL->{$profile} and defined EXTERNAL_BUREAU_URL->{$profile} and EXTERNAL_BUREAU_URL->{$profile} ne "") {
  $external_url = EXTERNAL_BUREAU_URL->{$profile};
}

# exteneral URL should be the platform URL unless it is defined within the hash
my $external_ssl_url = $platform_url;
if (exists EXTERNAL_SSL_BUREAU_URL->{$profile} and defined EXTERNAL_SSL_BUREAU_URL->{$profile} and EXTERNAL_SSL_BUREAU_URL->{$profile} ne "") {
  $external_ssl_url = EXTERNAL_SSL_BUREAU_URL->{$profile};
}

# WSO2 URL should be the platform URL unless it is defined within the hash
my $wso2_url = "http://linux5259.wic.west.com:8280";
if (exists WSO2_URL->{$profile} and defined WSO2_URL->{$profile} and WSO2_URL->{$profile} ne "") {
  $wso2_url = WSO2_URL->{$profile};
}

# IDS HOST should be the platform URL unless it is defined within the hash
my $ids_host = $platform_url;
if (exists IDS_HOST->{$profile} and defined IDS_HOST->{$profile} and IDS_HOST->{$profile} ne "") {
  $ids_host = IDS_HOST->{$profile};
}

my $base_log_directory  = "";
if (BASE_LOGDIRECTORIES->{$profile}->{$type} ne "") {
  $base_log_directory = BASE_LOGDIRECTORIES->{$profile}->{$type}
}
if(exists APPLICATION_BASE_DIRECTORY->{$profile} and 
  defined APPLICATION_BASE_DIRECTORY->{$profile} and 
          APPLICATION_BASE_DIRECTORY->{$profile} ne "") {
  $base_log_directory = APPLICATION_BASE_DIRECTORY->{$profile} . $base_log_directory;
} else {
  $base_log_directory = $base_dir . $base_log_directory;
}

my $prog_outdial_id_range_size = 1000000;
my $prog_outdial_id_range_start = 2000000;

if (exists OUTDIAL_PROG_ID_RANGE_SIZE->{$profile} and defined OUTDIAL_PROG_ID_RANGE_SIZE->{$profile}) {
 $prog_outdial_id_range_size = OUTDIAL_PROG_ID_RANGE_SIZE->{$profile};
}

if (exists OUTDIAL_PROG_ID_RANGE_START ->{$profile} and defined OUTDIAL_PROG_ID_RANGE_START ->{$profile}) {
 $prog_outdial_id_range_start = OUTDIAL_PROG_ID_RANGE_START ->{$profile};
}

if ($type eq "web") {
 $db_user = "NOT_PROVIDED";
 $db_password = "NOT_PROVIDED";
}

my $alarm_type =  uc($type);
if ($type eq "inet") {
  $alarm_type = "MGR";
}

my $survey_audio_directory = "";
if (exists SURVEY_AUDIO_DIRECTORY->{$profile}) {
  $survey_audio_directory = SURVEY_AUDIO_DIRECTORY->{$profile};
} 
my $primary_voice_directory = "";
if (exists PRIMARY_VOICE_DIRECTORY->{$profile}) {
  $primary_voice_directory = PRIMARY_VOICE_DIRECTORY->{$profile};
} 
my $secondary_voice_directory = "";
if (exists SECONDARY_VOICE_DIRECTORY->{$profile}) {
  $secondary_voice_directory = SECONDARY_VOICE_DIRECTORY->{$profile};
}

my $primary_file_directory = PRIMARY_FILE_DIRECTORY->{$profile};
 
my $secondary_file_directory = SECONDARY_FILE_DIRECTORY->{$profile};


my $cdrs = CDR_NAMES->{'default'};
if (exists CDR_NAMES->{$profile}) {
  $cdrs = CDR_NAMES->{$profile};
}

my $xoJob = XO_JOB_NAME->{'default'};
if (exists XO_JOB_NAME->{$profile}) {
  $xoJob = XO_JOB_NAME->{$profile};
}

# log levels
my $call_debugging = "YES";
if (exists CALL_DEBUGGING->{$profile} and defined CALL_DEBUGGING->{$profile} and CALL_DEBUGGING->{$profile} ne "") {
  $call_debugging = CALL_DEBUGGING->{$profile};
}

# log levels
my $app_loglevel = LOG_INFO;
if (exists APP_LOGLEVEL->{$profile}) {
  $app_loglevel = APP_LOGLEVEL->{$profile};
}
# log levels
my $core_loglevel = LOG_INFO;
if (exists CORE_LOGLEVEL->{$profile}) {
  $core_loglevel = CORE_LOGLEVEL->{$profile};
}

my $trigger_file_directory = "";
if (exists TRIGGER_FILE_DIRECTORY->{$profile}) {
  $trigger_file_directory = TRIGGER_FILE_DIRECTORY->{$profile};
}

my $a2w_qname = "a2w-b300-dev";
if (exists A2W_QUEUE_NAME->{$profile}) {
  $a2w_qname = A2W_QUEUE_NAME->{$profile};
}

my $alert_ws_server = "localhost:8084";
if(exists ALERT_WS_SERVER->{$profile}) {
  $alert_ws_server = ALERT_WS_SERVER->{$profile};
}

my $external_ip = "127.0.0.1";
if (exists EXTERNAL_IP_URL->{$profile}) {
  $external_ip = EXTERNAL_IP_URL->{$profile};
}

my $tep_server = 'localhost:8085';
if (exists TEP_WS_SERVER->{$profile}) {
  $tep_server = TEP_WS_SERVER->{$profile};
}

my $wng_xfer_routing_number = WNG_TRANSFER_ROUTING_NUMBER_DEFAULT;
if (exists WNG_TRANSFER_ROUTING_NUMBER_PLATFORM->{$profile}) {
  $wng_xfer_routing_number = WNG_TRANSFER_ROUTING_NUMBER_PLATFORM->{$profile};
}
if ($type eq "web") {
  $wng_xfer_routing_number = "";
}

my $tmp_directory  = "";
if (TMP_DIRECTORIES->{$profile}->{$type} ne "") {
  $tmp_directory = TMP_DIRECTORIES->{$profile}->{$type}
}

# Configure ucs-load-test.tfcci.com
my $hash = { 
                    'A2W_QUEUE_NAME' => $a2w_qname,
                    'ALERT_WS_SERVER' => $alert_ws_server,
                    'APP_LOGLEVEL' =>  $app_loglevel,
                    'CORE_LOGLEVEL' => $core_loglevel,
                    'TYPE'     => $alarm_type,
                    'MGR_LOG'     => $mgr_log,
                    'NO_REPL_SCHEMA'     => $norep_schema,
                    'SCHEMA'   => $schema,
                    'DB_USER'   => $db_user,
                    'DB_PASSWORD' => $db_password,
                    'DB'   => $db,
                    'XO_APP_ID' => $xo_app_id,
                    'SOAP_SERVER' => $soap_server,
                    'PAGE_SERVER' => $page_server,
                    'MQ_SERVER'  => $mq_server,
                    'MQ_PORT'    => $mq_port,
                    'MAP_SERVER' => $map_server,
                    'PLATFORM_URL' => $platform_url,
                    'ADMIN_BASE' => $admin_base,
                    'BASE_DIRECTORY' => $base_dir,
                    'OUTDIAL_PROG_ID_RANGE_START' => $prog_outdial_id_range_start,
                    'OUTDIAL_PROG_ID_RANGE_SIZE' => $prog_outdial_id_range_size,
                    'XML_BINARY_PROCESSSING' => $xmlParser,
                    'SOAPD_SCRIPT' => $soapScript,
                    'ARCHIVE_BASE_DIR' => $archive_base_dir,
                    'BASE_LOGDIRECTORY' => $base_log_directory, 
                    'INTERNAL_URL' => $internal_url, 
                    'EXTERNAL_URL' => $external_url,
                    'EXTERNAL_SSL_BUREAU_URL' => $external_ssl_url,
                    'SURVEY_AUDIO_DIRECTORY' => $survey_audio_directory,
                    'PRIMARY_VOICE_DIRECTORY' => $primary_voice_directory,
                    'SECONDARY_VOICE_DIRECTORY' => $secondary_voice_directory,
                    'WNGCDR'   => $cdrs->{wng},
                    'XOCDR'    => $cdrs->{xo},
                    'SMSCDR'   => $cdrs->{sms},
                    'FAXCDR'   => $cdrs->{fax},
                    'EMAILCDR' => $cdrs->{email},
                    'XOJOB'    => $xoJob,
                    'TRIGGER_FILE_DIRECTORY' => $trigger_file_directory,
                    'PRIMARY_FILE_STORAGE' => $primary_file_directory,
                    'SECONDARY_FILE_STORAGE' => $secondary_file_directory,
                    'EXTERNAL_IP_URL' => $external_ip,
                    'TEP_WS_SERVER' => $tep_server,
                    'TMP_DIRECTORY' => $tmp_directory, 
                    'WNG_TRANSFER_ROUTING_NUMBER' => $wng_xfer_routing_number,
                    'WSO2_URL' => $wso2_url,
                    'CALL_DEBUGGING' => $call_debugging,
										'IDS_HOST' => $ids_host
                };
                

my $template = Text::Template->new(TYPE => 'FILE',  SOURCE => 'PlatformConfig.tmpl');
my $text = $template->fill_in(HASH => $hash);

open CONFIG, ">PlatformConfig.pm.".lc($type);
print CONFIG $text;
close CONFIG;
