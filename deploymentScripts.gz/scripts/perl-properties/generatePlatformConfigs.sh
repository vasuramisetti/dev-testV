
if [ -z $1 ]; then 
echo "$0 <ATL01|DEN06|prod|prodden|test|testlab|training|beta|dev|qa|cwhite>";
exit
fi

rm -rf app web mgr adm inet

mkdir -p app/etc/perlAppServer
cp deployOnServer.sh app/.
mkdir -p app/etc/perlManagerServer
mkdir -p inet/etc/perlManagerServer
cp deployOnServer.sh inet/.
mkdir -p web/etc/perlWebServer
cp deployOnServer.sh web/.
mkdir -p adm/etc
cp deployOnServer.sh adm/.

echo "Generating Manager PlatformConfig"
perl gen_PlatformConfig.pl mgr $1
mv PlatformConfig.pm.mgr app/etc/perlManagerServer/PlatformConfig.pm
echo "Generating App PlatformConfig"
perl gen_PlatformConfig.pl app $1
mv PlatformConfig.pm.app app/etc/perlAppServer/PlatformConfig.pm
echo "Generating Inet PlatformConfig"
perl gen_PlatformConfig.pl inet $1
mv PlatformConfig.pm.inet inet/etc/perlManagerServer/PlatformConfig.pm
echo "Generating Web PlatformConfig"
perl gen_PlatformConfig.pl web $1
mv PlatformConfig.pm.web web/etc/perlWebServer/PlatformConfig.pm
echo "Generating Admin PlatformConfig"
perl gen_PlatformConfig.pl adm $1
mv PlatformConfig.pm.adm adm/etc/PlatformConfig.pm
echo "Generation Complete"
