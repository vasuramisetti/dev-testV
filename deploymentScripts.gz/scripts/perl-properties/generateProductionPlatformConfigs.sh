rm -rf sol10app sol9app denApp web adm webDen admDen

mkdir -p sol10app/etc/perlAppServer
mkdir -p sol10app/etc/perlManagerServer

mkdir -p sol10inet/etc/perlAppServer
mkdir -p sol10inet/etc/perlManagerServer

mkdir -p sol9app/etc/perlAppServer
mkdir -p sol9app/etc/perlManagerServer

mkdir -p denApp/etc/perlAppServer
mkdir -p denApp/etc/perlManagerServer

mkdir -p web/etc/perlWebServer
mkdir -p webDen/etc/perlWebServer

mkdir -p adm/etc
mkdir -p admDen/etc

perl gen_PlatformConfig.pl mgr prod > sol10app/etc/perlManagerServer/PlatformConfig.pm
perl gen_PlatformConfig.pl app prod > sol10app/etc/perlAppServer/PlatformConfig.pm
perl gen_PlatformConfig.pl inet prod > sol10inet/etc/perlManagerServer/PlatformConfig.pm
perl gen_PlatformConfig.pl inet prod > sol10inet/etc/perlAppServer/PlatformConfig.pm
perl gen_PlatformConfig.pl mgr prodden > denApp/etc/perlManagerServer/PlatformConfig.pm
perl gen_PlatformConfig.pl app prodden > denApp/etc/perlAppServer/PlatformConfig.pm
perl gen_PlatformConfig.pl app prod 1 > sol9app/etc/perlAppServer/PlatformConfig.pm
perl gen_PlatformConfig.pl mgr prod 1 > sol9app/etc/perlManagerServer/PlatformConfig.pm

perl gen_PlatformConfig.pl web prod > web/etc/perlWebServer/PlatformConfig.pm
perl gen_PlatformConfig.pl web prodden > webDen/etc/perlWebServer/PlatformConfig.pm

perl gen_PlatformConfig.pl adm prod > adm/etc/PlatformConfig.pm
perl gen_PlatformConfig.pl adm prodden > admDen/etc/PlatformConfig.pm
 