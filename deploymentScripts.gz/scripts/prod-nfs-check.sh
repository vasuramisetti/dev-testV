#!/bin/bash

echo -e "\033[31mATL01 App Servers\e[0m"
./nfs-check.sh --server sun68.anprod.com
./nfs-check.sh --server sun71.anprod.com
./nfs-check.sh --server sun74.anprod.com
./nfs-check.sh --server sun77.anprod.com

echo -e "\033[31mDEN06 App Servers\e[0m"
./nfs-check.sh --server sun81.anprod.com
./nfs-check.sh --server sun84.anprod.com
./nfs-check.sh --server sun87.anprod.com
./nfs-check.sh --server sun90.anprod.com


echo -e "\033[31mStandard Legacy Password\e[0m"
./nfs-check.sh --server ivr1.cmh.tfcci.local --user bluebox

./nfs-check.sh --server app1denucs.tfcci.local --user phoenix
./nfs-check.sh --server app2denucs.tfcci.local --user phoenix

echo -e "\033[31mPrevious legacy Password\e[0m"
./nfs-check.sh --server ivr1den.tfcci.local --user bluebox
