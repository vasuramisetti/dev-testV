#!/bin/bash
# Change the directory so sudo works
cd /opt/tfcc/ucs/deploy
echo "Prompt is for sudo password"
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/ucsftp/system/tecoucsftp/PAU
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/ucsftp/system/tecoucsftp/MAF
/opt/sfw/bin/sudo chown -R tfccapp:tfcccdat /opt/tfcc/ucs/nfs-files-local-datacenter/ucsftp
/opt/sfw/bin/sudo chmod -R 775 /opt/tfcc/ucs/nfs-files-local-datacenter/ucsftp
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/tep/archive
/opt/sfw/bin/sudo chown -R tfccapp:tfcccdat /opt/tfcc/ucs/nfs-files-local-datacenter/tep
/opt/sfw/bin/sudo chmod -R 775 /opt/tfcc/ucs/nfs-files-local-datacenter/tep
rm /opt/tfcc/ucs/deploy/SDR_5073873.sh
