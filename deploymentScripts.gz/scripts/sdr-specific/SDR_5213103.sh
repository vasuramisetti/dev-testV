/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/dultfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/dultfccucs/aum-prod

/opt/sfw/bin/sudo chown -R tfccapp:tfcccdat /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm
/opt/sfw/bin/sudo chmod -R 775 /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm