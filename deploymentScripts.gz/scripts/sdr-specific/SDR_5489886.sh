/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/comamitfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/comamitfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/cectfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/cectfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/cecbilltfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/cecbilltfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/ceccpptfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/ceccpptfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/cectesttfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/cectesttfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/laktfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/laktfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/lestfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/lestfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/nsptfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/nsptfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/pedtfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/pedtfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/peptfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/peptfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/smudtfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/smudtfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/scsiptfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/scsiptfccucs/aum-prod
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/tecotfccucs/aum-test
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/tecotfccucs/aum-prod

/opt/sfw/bin/sudo chown -R tfccapp:tfcccdat /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm
/opt/sfw/bin/sudo chmod -R 775 /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm