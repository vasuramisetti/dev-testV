/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/scsiptfccucs/pre-conv
/opt/sfw/bin/sudo mkdir -p /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm/scsiptfccucs/apc_oncall/pre-conv

/opt/sfw/bin/sudo chown -R tfccapp:tfcccdat /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm
/opt/sfw/bin/sudo chmod -R 775 /opt/tfcc/ucs/nfs-files-local-datacenter/wni-farm