#!/bin/bash

IMPORT_COMMAND="/opt/sfw/bin/sudo /usr/sbin/svccfg import"
PERL_MANAGER_ROOT="/opt/tfcc/ucs/app/managers/svc/xml"
JAVA_MANAGER_ROOT="/opt/tfcc/ucs/java-managers/svc"


# print usage info
function usage
{
  echo "usage: $0 [-s] [-u]"
  echo "     -m | --mode                  MODE of script [SHUTDOWN|STARTUP|CREATE] Default CREATE "
  echo "     -s | --server                REQUIRED - Server IE esx-app07ucstest.cmh.tfcci.local"
  echo "     -h | --help                    help print this usage"
  echo "     -u | --user                    Your username for deploying applications"
  echo "                                      Defaults to whoami"
}

if [ -z $1 ]; then 
echo "No parameters provided, please see usage below:"
usage
exit
fi

USERNAME=`whoami`
server=
USER=`whoami`
MODE="CREATE"


while [ "$1" != "" ]; do
#    echo $1
    case $1 in
        -s | --server )            shift
                                     server=$1
                                     ;;
        -m | --mode )                shift
                                     MODE=$1
                                     ;;                                   
        -h | --help )                usage
                                     exit
                                     ;;
        -u | --user)                 shift
                                     USER=$1
                                     ;;        
        * )                          usage
                                     exit 1
    esac
    shift
done


if [ -z $server ]; then 
echo "No server provided!"
usage
exit
fi

DEPLOYMENT_LOCATION=/opt/tfcc/ucs/deploy/$USER/reboot

REMOTE_COMMAND="ssh -t $USERNAME@"

COMMANDS=""

function createCommands {

COMMANDS=""
if [ $MODE = "SHUTDOWN" ] || [ $MODE = "CREATE" ]; then
  COMMANDS=$COMMANDS"services=\`svcs  'ucs/app/*' | grep online | cut -b 25- | grep 'ucs/app' $EXCLUDE | grep -v alarmd | tr \"\n\" \" \"\`
  echo \"/opt/sfw/bin/sudo /usr/sbin/svcadm disable -ts \$services\" >> $DEPLOYMENT_LOCATION/rebootDisable.sh
  echo \"/opt/sfw/bin/sudo /usr/sbin/svcadm enable -s \$services\" >> $DEPLOYMENT_LOCATION/rebootStartup.sh
  /opt/sfw/bin/sudo chmod +x $DEPLOYMENT_LOCATION/*.sh
  "
fi
if [ $MODE = "SHUTDOWN" ]; then 
  COMMANDS=$COMMANDS"if [ -a $DEPLOYMENT_LOCATION/rebootDisable.sh ]; then
  echo 'Services Running:'
  /usr/bin/svcs -a | /usr/bin/grep ucs | /usr/bin/grep -c online
  $DEPLOYMENT_LOCATION/rebootDisable.sh
else 
  echo \"No Services found to shutdown\"
fi
  "
fi
  if [ $MODE = "STARTUP" ]; then
   COMMANDS=$COMMANDS"
if [ -a $DEPLOYMENT_LOCATION/rebootStartup.sh ]; then
  $DEPLOYMENT_LOCATION/rebootStartup.sh
  echo 'Services online'
  /usr/bin/svcs -a | /usr/bin/grep ucs | /usr/bin/grep -c online
else 
  echo \"No Services found to startup\"
fi
"
  fi

}


createCommands

echo "Setting Up Appserver : $server";
echo "$COMMANDS" > remoteControlScript.sh;
ssh -t $USER@$server mkdir -p $DEPLOYMENT_LOCATION;
scp remoteControlScript.sh $USER@$server:$DEPLOYMENT_LOCATION;
ssh -t $USER@$server chmod +x $DEPLOYMENT_LOCATION/remoteControlScript.sh;
ssh -t $USER@$server $DEPLOYMENT_LOCATION/remoteControlScript.sh


echo "Cleaning Up Configurations"
rm remoteControlScript.sh
echo "Clean up Completed"
echo "End of Script"
