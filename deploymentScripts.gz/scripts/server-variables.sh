#!/bin/bash

ATL01_APPS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com"
ATL01_WEBS="sun56.anprod.com sun59.anprod.com sun62.anprod.com sun65.anprod.com"
ATL01_INETS=""
ATL01_ADMS=""

DEN06_APPS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"
DEN06_WEBS="sun39.anprod.com sun42.anprod.com sun45.anprod.com sun48.anprod.com"
DEN06_INETS=""
DEN06_ADMS=""

PREPROD_APPS="app-pre-1-ucs.utilities.west.com app-pre-2-ucs.utilities.west.com"
PREPROD_WEBS="web-pre-1-ucs.utilities.west.com web-pre-2-ucs.utilities.west.com"
PREPROD_INETS=""
PREPROD_ADMS=""

BETA_APPS="app-dev-1-ucs.utilities.west.com"
BETA_WEBS="web-dev-1-ucs.utilities.west.com"
BETA_INETS=""
BETA_ADMS=""

DEV_APPS="myapp"
DEV_WEBS="myweb"

getServers ()  {
  platform=$1
  class=$2
  key="${platform}_${class}";
    case $key in
       ALLPROD_APP )    servers="$ATL01_APPS $DEN06_APPS";;
       ALLPROD_WEB )    servers="$ATL01_WEBS $DEN06_WEBS";;
       ALLPROD_INETS )  servers="$ATL01_INETS $DEN06_INETS";;
       ALLPROD_ADMS )   servers="$ATL01_ADMS $ATL01_ADMS";;
       DEN06_APP )      servers=$DEN06_APPS;;
       DEN06_WEB )      servers=$DEN06_WEBS;;
       DEN06_INETS )    servers=$DEN06_INETS;;
       DEN06_ADMS )     servers=$DEN06_ADMS;;
       ATL01_APP )      servers=$ATL01_APPS;;
       ATL01_WEB )      servers=$ATL01_WEBS;;
       ATL01_INETS )    servers=$ATL01_INETS;;
       ATL01_ADMS )     servers=$ATL01_ADMS;;
       PREPROD_APP )    servers=$PREPROD_APPS;;
       PREPROD_WEB )    servers=$PREPROD_WEBS;;
       PREPROD_INETS )  servers=$PREPROD_INETS;;
       PREPROD_ADMS )   servers=$PREPROD_ADMS;;
       BETA_APP )       servers=$BETA_APPS;;
       BETA_WEB )       servers=$BETA_WEBS;;
       BETA_INETS )     servers=$BETA_INETS;;
       BETA_ADMS )      servers=$BETA_ADM;;
       DEV_APP )        servers=$DEV_APPS;;
       DEV_WEB )        servers=$DEV_WEBS;;
       * )               echo "Unexpected Platform/Class Combination"
                         exit 1
    esac
 
}


