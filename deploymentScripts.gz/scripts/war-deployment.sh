#!/bin/bash
################################################################
# TFCC Alert Web Application WAR Deployment
################################################################
export PATH=$PATH:/opt/sfw/bin:/usr/sfw/bin:/usr/sbin

TFCC_USER="tfccsrv";
TFCC_GROUP="tfcclog";

SUDO="/opt/sfw/bin/sudo"
UNZIP="/usr/bin/unzip"
WGET="/usr/local/bin/wget -O wget-mod_jk "
WGET_WAR="wget --proxy=off"
SCRIPT_PATH=`dirname "$BASH_SOURCE"`
SNAPSHOT_TEMP_FILE="snapshot-maven-metadata.xml"
SNAPSHOT_TEMP_SCRIPT="snapshot-script.sh"
SNAPSHOT_XSLT="xsltproc $SCRIPT_PATH/snapshot.xslt"

TOMCAT_WEBAPP_DIR="java/"

WGET_LOCAL="wget --proxy=off"

TOP_DOMAIN="utilities.west.com"

AN_TOP_DOMAIN="anprod.com"

VERSION_RELEASE_URL="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-releases/com/tfcci/ucs/TFCCAlert/maven-metadata.xml"
VERSION_SNAPSHOT_URL="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-snapshots/com/tfcci/ucs/TFCCAlert/maven-metadata.xml"
SNAPSHOT_TEMP_FILE="snapshot-maven-metadata.xml"
SNAPSHOT_TEMP_SCRIPT="snapshot-script.sh"
SNAPSHOT_XSLT="xsltproc $SCRIPT_PATH/snapshot.xslt"
VERSION_XSLT="xsltproc $SCRIPT_PATH/version.xslt"
VERSION_URL="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-releases/com/tfcci/ucs/TFCCAlert/maven-metadata.xml"
VERSION_TEMP_FILE="maven-metadata.xml"
VERSION_TEMP_SCRIPT="version-script.sh"
USER=$(whoami)
SERVER_BASE=/opt/tfcc/ucs

JK_START_URL="/jkmanager/?cmd=update&vwa=0&w=loadbalancer&sw="
JK_STOP_URL="/jkmanager/?cmd=update&vwa=2&w=loadbalancer&sw="

APP_JK_START_URL="/jkmanager/?cmd=update&vwa=0&w=loadbalancer-tomcat1&sw="
APP_JK_STOP_URL="/jkmanager/?cmd=update&vwa=2&w=loadbalancer-tomcat1&sw="

PREPROD_SERVERS="app-pre-1-ucs.utilities.west.com app-pre-2-ucs.utilities.west.com"
PREPROD_WEBS="web-pre-1-ucs web-pre-1-ucs"
PREPROD_NODES=( "app-pre-1-ucs" "app-pre-2-ucs" );

BETA_SERVERS="app-dev-1-ucs.utilities.west.com"
BETA_WEBS="web-dev-1-ucs"
BETA_NODES=( "app-dev-1-ucs" );

DEVLAB_SERVERS="myapp"
DEVLAB_WEBS="myweb"
DEVLAB_NODES=( "node1" );

QA_SERVERS="app-qa-1-ucs.utilities.west.com app-qa-2-ucs.utilities.west.com"
QA_WEBS="web-qa-1-ucs.utilities.west.com web-qa-2-ucs.utilities.west.com"
QA_NODES=( "node1"  "node2" );

PROD_CMH_SERVERS="app1ucs.cmh.tfcci.local app2ucs.cmh.tfcci.local app3ucs.cmh.tfcci.local app4ucs.cmh.tfcci.local"
PROD_CMH_WEBS="web01ucs.cmh web02ucs.cmh web03ucs.cmh web04ucs.cmh"
PROD_CMH_NODES=( "node1" "node3" "node2" "node4" );

PROD_DEN_SERVERS="app1denucs.tfcci.local app2denucs.tfcci.local"
PROD_DEN_WEBS="web1denucs web2denucs"
PROD_DEN_NODES=( "node1" "node2" );


SWN01_SERVERS="sun68.anprod.com sun71.anprod.com sun74.anprod.com sun77.anprod.com"
SWN01_WEBS="sun56 sun59 sun62 sun65"
SWN01_NODES=( "sun68" "sun71" "sun74" "sun77");

DEN06_SERVERS="sun81.anprod.com sun84.anprod.com sun87.anprod.com sun90.anprod.com"
DEN06_WEBS="sun39 sun42 sun45 sun48"
DEN06_NODES=( "sun81" "sun84" "sun87" "sun90" );

BUILD_OUT_SERVER="ucsapptest2.tfcci.local"

NEXUS_RELEASE_SERVER="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-releases/com/tfcci/ucs"
NEXUS_SNAPSHOT_SERVER="http://build.utilities.west.com:8081/nexus/content/repositories/tfcc-internal-snapshots/com/tfcci/ucs"

TMP_DIR=".ta-deployment"
TOMCAT_WEBAPP_DIR="$SERVER_BASE/tomcat1/webapps"
TOMCAT_CACHE_DIR="$SERVER_BASE/tomcat1/work/Catalina/localhost"

TOMCAT_STARTUP="/opt/sfw/bin/sudo /usr/sbin/svcadm enable -s ucs/srv/tomcat1"
TOMCAT_SHUTDOWN="/opt/sfw/bin/sudo /usr/sbin/svcadm disable -s ucs/srv/tomcat1"


function countdown
{
        local OLD_IFS="${IFS}"
        IFS=":"
        local ARR=( $1 )
        local SECONDS=$((  (ARR[0] * 60 * 60) + (ARR[1] * 60) + ARR[2]  ))
        local START=$(date +%s)
        local END=$((START + SECONDS))
        local CUR=$START

        while [[ $CUR -lt $END ]]
        do
                CUR=$(date +%s)
                LEFT=$((END-CUR))

                printf "\r%02d:%02d:%02d" \
                        $((LEFT/3600)) $(( (LEFT/60)%60)) $((LEFT%60))

                sleep 1
        done
        IFS="${OLD_IFS}"
        echo "        "
}

function cleanup
{

# remove temp directory
echo "Cleaning up...";
rm -rf $TMP_DIR

}

# print usage info
function usage
{
  echo "usage: war_deployment.sh [-l] [-p] [-n] [-t] [-d] [-h]"
  echo "     -n | --non-interactive       non-interactive"
  echo "     -l | --location              deployment location [QA|PROD|BETA|SWN01|DEN06]"
  echo "     -p | --project               project to deploy [ucs-web|...|all|all-alert]"
  echo "     -t                           pull from target"
  echo "     -s | --source                '2' for Nexus (use -t for target)"
  echo "     -r | --repository            '1' - RELEASE,  '2' - SNAPSHOT"
  echo "     -v | --version               Version to pull down if source is Nexus (not required for target)"
  echo "     -d | --dir                   workspace directory [trunk|1.1.x|...] default: trunk"
  echo "     -h | --help                  help print this usage"
  echo "     -q | --quick                 Does not sleep waiting for servers to come back up "
  echo "     --tmp-dir                   temporary directory"
}


# create dirs
function make_dirs {
  local APP_DIRS="$SERVER_BASE/tmp $SERVER_BASE/etc";

  for s in $SERVERS
  do
    echo "Checking for required dirs on $s";
    echo "--------------------------------";
    for dir in $APP_DIRS
    do
      echo "  Checking $dir dir;  ssh $USER@$s test -d $dir";
      #if [ `ssh -t $USER@$s "test -d $dir"`]; then
      ssh -t $USER@$s test -d $dir
      if [ $? -ne 0 ]; then
        # create dir
        echo "ssh -t $USER@$s $SUDO_TFCCAPP mkdir -p $dir";
        ssh -t $USER@$s $SUDO mkdir -p $dir

        # chaange owner/group
        #echo "ssh -t $USER@$s $SUDO_TFCCAPP chown $TFCC_USER:$TFCC_GROUP $dir";
        #ssh -t $USER@$s $SUDO_TFCCAPP chown $TFCC_USER:$TFCC_GROUP $dir
        echo "ssh -t $USER@$s $SUDO chown $TFCC_USER:$TFCC_GROUP $dir";
        ssh -t $USER@$s $SUDO chown $TFCC_USER:$TFCC_GROUP $dir

        # set permissions
        #echo "ssh -t $USER@$s $SUDO_TFCCAPP chmod 775 $dir";
        #ssh -t $USER@$s $SUDO_TFCCAPP chmod 775 $dir
        echo "ssh -t $USER@$s $SUDO chmod 775 $dir";
        ssh -t $USER@$s $SUDO chmod 775 $dir
      else 
        echo "$dir already exists. Skipping ...";
      fi
    done
    for p in $PROJECTS
    do
     echo "Checking for WAR file on Server: $s@$SERVER_BASE/deploy/$USER/java-web/$p.war"
     ssh -t $USER@$s test -s $SERVER_BASE/deploy/$USER/java-web/$p.war
     if [ $? -ne 0 ]; then
       echo "WAR file not found on remove machine: $SERVER_BASE/deploy/$USER/java-web/$p.war";
       exit 1;
     fi
    done;
  done
}

##########################################
# Main
##########################################

# set defaults
interactive=1
from_target=0
platform=
project=
target_dir_base="trunk"
version=
no_sleep=0


while [ "$1" != "" ]; do
    #echo $1
    case $1 in
        -l | --location )            shift
                                     platform=$1
                                     ;;
        -p | --project )             shift
                                     project=$1
                                     ;;
        -t )                        from_target=1
                                     ;;
        -d | --dir )                 shift
                                     target_dir_base=$1
                                     ;;
        -n | --non-interactive )     interactive=0
                                     ;;
        -v | --version)              shift
                                     version=$1
                                     ;;
        -s | --source)               shift
                                     source=$1
                                     ;;
        -r | --repository)           shift
                                     repository=$1
                                     ;;
        -u | --user)                 shift
                                     USER=$1;;
        --tmp-dir)                   shift
                                     TMP_DIR=$1;;
        -q | --quick)                shift
                                     no_sleep=1;;
        -h | --help )                usage
                                     exit
                                     ;;
        * )                          usage
                                     exit 1
    esac
    shift
done

# set the target dir base
TARGET_DIR_BASE=$target_dir_base

VERSION_URL=$VERSION_RELEASE_URL
NEXUS_SERVER=$NEXUS_RELEASE_SERVER

if [ $interactive = 1 ]; then
  ########################################
  # Interactive mode
  ########################################
  
  echo "Entering interactive mode..."
  
  # get USER
  echo "#############################################"
  echo "Which user are you using for the deployment?"
  echo "#############################################"
  echo "1) $USER"
  echo "2) Another User"
  echo "? "

  read -e useroption
    
  if [ $useroption = 2 ]; then
    echo "#############################################"
    echo "Please enter the user name you are going to"
    echo " use for the deployment"
    echo "#############################################"
    read -e USER
  fi
  
  # get platform
  echo "#############################################"
  echo "Which platform would you like to deploy to?"
  echo "#############################################"
  echo "1) Prod-CMH"
  echo "2) Prod-DEN"
  echo "3) QA"
  echo "4) Beta"
  echo "5) Preprod"
  echo "6) Prod-SWN01"
  echo "7) Prod-DEN06"
  echo "? "

  read -e platform

  # get project
  echo "#########################################"
  echo "Which project(s) would you like to deploy?"
  echo "#########################################"
  echo "1) Client Web (ucs-web)"
  echo "2) Internal Web Services (ucs-ws-internal)"
  echo "3) IVR Support (ucs-ivr)"
  echo "4) External Web Services (ucs-ws)"
  echo "5) SMS Keyword Router (keyword-router)"
  echo "6) Client Mobile Web (ucs-web-mobile)"
  echo "7) View Online Web (view-online-web)"
  echo "all) all projects"
  echo "all-alert) All the Alert Specific Wars"
  echo "? "

  read -e project
  
  if [ $from_target = 1 ]; then
    echo "#########################################"
    echo "Target Chosen Version not required"
    echo "#########################################"
  else
   
  # get source
  echo "#########################################"
  echo "Where do you want to retreive the binarys from?"
  echo "#########################################"
  echo "1) From Target (Hudson)"
  echo "2) Nexus Respository"
  echo "? "

  read -e source
  
  
  if [ $source = 1 ]; then
     echo "#########################################"
     echo "Please type the target absolute path below."
     echo "#########################################"
     read -e TARGET_DIR_BASE
  fi # End source = 1
  # if source = 2
  if [ $source = 2 ]; then
    # get source
    echo "#########################################"
    echo "Do you want a SNAPSHOT or RELEASE?"
    echo "#########################################"
    echo "1) Release"
    echo "2) Snapshot"
    echo "? "

    read -e repository

    if [ $repository = 2 ]; then 
      VERSION_URL=$VERSION_SNAPSHOT_URL
      NEXUS_SERVER=$NEXUS_SNAPSHOT_SERVER
      snapshot=1
    fi # end repository = 2
  
    echo "Determining Available Versions"
    #echo "$WGET_WAR --quiet --output-document=$VERSION_TEMP_FILE $VERSION_URL"
    $WGET_WAR --quiet --output-document=$VERSION_TEMP_FILE $VERSION_URL
    #echo "$VERSION_XSLT $VERSION_TEMP_FILE > $VERSION_TEMP_SCRIPT"
    $VERSION_XSLT $VERSION_TEMP_FILE > $VERSION_TEMP_SCRIPT
    rm $VERSION_TEMP_FILE
    # get version
    echo "##############################################"
    echo "What version of the release are you deploying?"
    echo "##############################################"
    source ./$VERSION_TEMP_SCRIPT
    rm $VERSION_TEMP_SCRIPT
    
  fi # end source = 2
  fi # End from_target = 1
  #######################################################################
  # End interactive mode
  #######################################################################
  
else
  echo "Entering non-ineractive mode...";
fi

case $platform in
"1" | "PROD-CMH")
  PLATFORM="Production-CMH"
  SERVERS=$PROD_CMH_SERVERS
  WEBS=$PROD_CMH_WEBS
  NODES=( "${PROD_CMH_NODES[@]}" );
  WAR_DIR="java/wars/tfccalert-prod";;
"2" | "PROD-DEN")
  PLATFORM="Production-DEN"
  SERVERS=$PROD_DEN_SERVERS
  WEBS=$PROD_DEN_WEBS
  NODES=( "${PROD_DEN_NODES[@]}" );
  WAR_DIR="java/wars/tfccalert-prod";;  
"3" | "QA")
  PLATFORM="QA/Test"
  SERVERS=$QA_SERVERS
  WEBS=$QA_WEBS
  NODES=( "${QA_NODES[@]}" );
  WAR_DIR="java/wars/tfccalert-qa";;
"4" | "BETA" | "DEMO")
  PLATFORM="Beta"
  SERVERS=$BETA_SERVERS
  WEBS=$BETA_WEBS
  NODES=( "${BETA_NODES[@]}" );
  WAR_DIR="java/wars/tfccalert-beta";;
"5" | "PREPROD")
  PLATFORM="Preprod"
  SERVERS=$PREPROD_SERVERS
  WEBS=$PREPROD_WEBS
  NODES=( "${PREPROD_NODES[@]}" );
  WAR_DIR="java/wars/tfccalert-preprod";;
"6" | "SWN01")
  TOP_DOMAIN=$AN_TOP_DOMAIN
  PLATFORM="Prod - SWN01"
  SERVERS=$SWN01_SERVERS
  WEBS=$SWN01_WEBS
  NODES=( "${SWN01_NODES[@]}" );
  WAR_DIR="java/wars/tfccalert-prod-SWN01";;
"7" | "DEN06")
  TOP_DOMAIN=$AN_TOP_DOMAIN
  PLATFORM="Prod - DEN06"
  SERVERS=$DEN06_SERVERS
  WEBS=$DEN06_WEBS
  NODES=( "${DEN06_NODES[@]}" );
  WAR_DIR="java/wars/tfccalert-prod-DEN06";;
*)
  echo "Invalid platform.  Exiting..."
  exit 1;
esac

case $project in
"1" | "ucs-web")
  PROJECTS="ucs-web";;
"2" | "ucs-ws-internal")
  PROJECTS="ucs-ws-internal";;
"3" | "ucs-ivr")
  PROJECTS="ucs-ivr";;
"4" | "ucs-ws")
  PROJECTS="ucs-ws";;
"5" | "keyword-router")
  PROJECTS="keyword-router";;
"6" | "ucs-web-mobile")
  PROJECTS="ucs-web-mobile";; 
"7" | "view-online-web")
  PROJECTS="view-online-web";; 
"all")
  PROJECTS="ucs-web ucs-ws-internal ucs-ivr ucs-ws keyword-router view-online-web";;
"all-alert")
  PROJECTS="ucs-web ucs-ws-internal ucs-ivr ucs-ws view-online-web";;
*)
  echo "Invalid project.  Exiting..."
  exit 1;
esac


# confirm
echo "   "
echo "Actions to be performed: "
echo -e " Deploy to "'\E[37;44m'"\033[1m$PLATFORM\033[0m:"
echo "   USER:           $USER"
echo "   PROJECTS:       $PROJECTS"
echo "   TC SERVERS:     $SERVERS"
echo "   TC NODES:       ${NODES[@]}"
echo "   MOD_JK SERVERS: ${WEBS[@]}"
echo "   TEMP-DIR:       ${TMP_DIR}"

if [ $from_target = 1 ]; then
  echo "CommandLine option equivalent: $0 -n -l $platform -t -d $TARGET_DIR_BASE -u $USER -s 1 -p $project"
else

  if [ $source = 1 ]; then
    echo "   Target Directory: $TARGET_DIR_BASE"
    echo "CommandLine option equivalent: $0 -n -l $platform -t -d $TARGET_DIR_BASE -u $USER -s 1 -p $project"
  fi
  if [ $source = 2 ]; then
    echo "   Repository: $VERSION_URL"
    echo "   Version: $version"
    echo "CommandLine option equivalent: $0 -n -l $platform -u $USER -s 2 -r $repository -v $version -p $project"
  fi


  if [ -z "$version" ]; then
    echo "ERROR: Version not provided, exiting!"
    exit 1;
  fi  
  echo "   VERSION: $version"
fi

if [ $interactive = 1 ]; then
  echo " Would you like to proceed? (Y/N)"    

  read -e proceed
  case $proceed in
  "Y" | "y")
    ;;
  *)
    echo "Exiting..."
    exit 1;;
  esac
fi

if [ $source = 2 ]; then
  if [ $repository = 2 ]; then
     VERSION_URL=$VERSION_SNAPSHOT_URL
     NEXUS_SERVER=$NEXUS_SNAPSHOT_SERVER
     snapshot=1
  fi
fi

DEPLOYMENT_STAGING_LOCATION=$SERVER_BASE/deploy/$USER/java-web
# create tmp dir
echo "Creating temporary directory ($TMP_DIR)...";
rm -rf $TMP_DIR
mkdir $TMP_DIR

if [ $from_target = 1 ]; then
  # copy files from target directory
  echo "Copying files from target dirs to pre-deployment locations on tomcat servers..."
  for a in $SERVERS
  do

    echo "  Copying to $a..."
    for p in $PROJECTS
    do
      echo "   $TARGET_DIR_BASE/$p/target/$p.war ---> $USER@$a:$DEPLOYMENT_STAGING_LOCATION/."
      cp $TARGET_DIR_BASE/$p/target/$p.war $TMP_DIR/$p.war
    done
  done
else 
  # pull files
  echo "Pulling war files from build deployment location...";


  
  for p in $PROJECTS
  do

  if [ $snapshot = 1 ]; then
    retrieval_version=`echo $version | cut -d'-' -f 1`
    echo " $WGET_LOCAL --quiet --output-document=$SNAPSHOT_TEMP_FILE $NEXUS_SNAPSHOT_SERVER/$p/$version/maven-metadata.xml"
    $WGET_LOCAL --quiet --output-document=$SNAPSHOT_TEMP_FILE $NEXUS_SNAPSHOT_SERVER/$p/$version/maven-metadata.xml
    echo "$SNAPSHOT_XSLT $SNAPSHOT_TEMP_FILE > $SNAPSHOT_TEMP_SCRIPT"
    cat $SNAPSHOT_TEMP_FILE
    $SNAPSHOT_XSLT $SNAPSHOT_TEMP_FILE > $SNAPSHOT_TEMP_SCRIPT
    source $SNAPSHOT_TEMP_SCRIPT;
    fileRoot="$p-$retrieval_version-$snapshot_file";
    rm $SNAPSHOT_TEMP_SCRIPT $SNAPSHOT_TEMP_FILE
    NEXUS_SERVER=$NEXUS_SNAPSHOT_SERVER
  else
    fileRoot="$p-$version"
  fi
  
    $WGET_WAR --output-document=$TMP_DIR/$p.war $NEXUS_SERVER/$p/$version/$fileRoot.war
    echo "$WGET_WAR --output-document=\"$TMP_DIR/$p.war\" \"$NEXUS_SERVER/$p/$version/$p-$version.war\""
  done
fi
  for a in $SERVERS
  do
    echo "Creating Deployment Staging Location"
    ssh -t $USER@$a mkdir -p $DEPLOYMENT_STAGING_LOCATION
    echo "Deployment Staging Location Created"
    echo "  Copying to $a..."
    for p in $PROJECTS
    do
      scp $TMP_DIR/$p.war $USER@$a:$DEPLOYMENT_STAGING_LOCATION/.
      echo "scp $TMP_DIR/$p.war $USER@$a:$DEPLOYMENT_STAGING_LOCATION/."
    done
  done

  # make remote dirs if necessary
  make_dirs

n=0
w=0
for a in $SERVERS
do
  echo "DEPLOYING TO $a:";
  echo "Stopping mod_jk routing to $a...";
  node=${NODES[$n]}
  for web in $WEBS
  do
    echo "Disabling $node on $web..."
    $WGET "http://$web.$TOP_DOMAIN$JK_STOP_URL$node"
  done
  for appServer in $SERVERS
  do  
    echo "Disabling $node-tomcat1 on $appServer"
    $WGET "http://$appServer$APP_JK_STOP_URL$node-tomcat1"
  done
  echo "Shutting down tomcat on $a...";
  ssh -t $USER@$a $TOMCAT_SHUTDOWN
  if [ $no_sleep = 1 ]; then
    echo "No Sleep Quick Deployment"
  else 
    echo "Waiting for tomcat shutdown...";
    /usr/bin/telnet $a 8084
    echo "Telnet will close once tomcat is shutdown"
  fi
  echo "Deploying apps on $a...";
  for p in $PROJECTS
  do
    echo "  Moving WAR $p... Cleaning Up last version.";
    ssh -t $USER@$a "$SUDO cp $DEPLOYMENT_STAGING_LOCATION/$p.war $TOMCAT_WEBAPP_DIR/$p.war; $SUDO chown tfccsrv:tfccapp $TOMCAT_WEBAPP_DIR/$p.war; cd /opt/tfcc/ucs; $SUDO rm -rf $TOMCAT_WEBAPP_DIR/$p; $SUDO rm -rf $TOMCAT_CACHE_DIR/$p; $SUDO rm -rf $TOMCAT_CACHE_DIR/$p"
  done
  echo "Cleaning up Staging Location"
  echo "Starting tomcat on $a...";
  ssh -t $USER@$a "cd /opt/tfcc/ucs; $SUDO rm -rf $DEPLOYMENT_STAGING_LOCATION; $TOMCAT_STARTUP"
  if [ $no_sleep = 1 ]; then
    echo "No Sleep Quick Deployment"
  else 
    echo "Waiting for tomcat startup.... Waiting up to 600 seconds";
    for p in $PROJECTS
    do
      echo "$WGET_WAR  --retry-connrefused  --timeout=600 --delete-after $a:8084/$p";
      $WGET_WAR --retry-connrefused --timeout=600 --delete-after $a:8084/$p;
    done
  fi
  echo "Resuming mod_jk routing to $a...";
  for web in $WEBS
  do
    echo "Enabling $node on $web..."
    $WGET "http://$web.$TOP_DOMAIN$JK_START_URL$node"
  done
  for appServer in $SERVERS
  do  
    echo "Enabled $node-tomcat1 on $appServer"
    $WGET "http://$appServer$APP_JK_START_URL$node-tomcat1"
  done
  # next node
  let "n++";
done

echo "Deployment complete.";

# cleanup
cleanup

# exit
echo "Exiting...";
